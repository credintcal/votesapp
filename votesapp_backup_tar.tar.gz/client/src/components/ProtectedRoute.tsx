import React from 'react';
import { Navigate, useLocation } from 'react-router-dom';

interface ProtectedRouteProps {
  children: React.ReactNode;
}

const ProtectedRoute: React.FC<ProtectedRouteProps> = ({ children }) => {
  const location = useLocation();
  
  // Check if user is authenticated by looking for auth data in localStorage
  // In a real app, this would be more robust, using a proper auth state management system
  const isAuthenticated = localStorage.getItem('user') !== null;

  if (!isAuthenticated) {
    // Redirect to login page if not authenticated, preserving the intended destination
    return <Navigate to="/auth/login" state={{ from: location }} replace />;
  }

  return <>{children}</>;
};

export default ProtectedRoute; 