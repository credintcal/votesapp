import React, { lazy, Suspense } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import './App.css';

// Layouts
import MainLayout from './layouts/MainLayout';
import AuthLayout from './layouts/AuthLayout';
import AdminLayout from './layouts/AdminLayout';
import ClientLayout from './layouts/ClientLayout';

// Components
import ProtectedRoute from './components/ProtectedRoute';

// Auth Pages
const Login = lazy(() => import('./pages/auth/Login'));
const Register = lazy(() => import('./pages/auth/Register'));
const VerifyOTP = lazy(() => import('./pages/auth/VerifyOTP'));

// Public Pages
const Home = lazy(() => import('./pages/public/Home'));
const About = lazy(() => import('./pages/public/About'));
const PollDetails = lazy(() => import('./pages/public/PollDetails'));

// User Pages
const Feed = lazy(() => import('./pages/Feed'));

// Client Pages
const ClientDashboard = lazy(() => import('./pages/client/Dashboard'));
const ClientAreaMap = lazy(() => import('./pages/client/AreaMap'));
const CreatePoll = lazy(() => import('./pages/client/CreatePoll'));

// Admin Pages
const Dashboard = lazy(() => import('./pages/admin/Dashboard'));
const AdminCreatePoll = lazy(() => import('./pages/admin/CreatePoll'));
const PollResults = lazy(() => import('./pages/admin/PollResults'));
const ManagePolls = lazy(() => import('./pages/admin/ManagePolls'));
const HeatMap = lazy(() => import('./pages/admin/HeatMap'));

// Loader Component
const Loader = () => (
  <div className="flex items-center justify-center min-h-screen">
    <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-primary-600"></div>
  </div>
);

function App() {
  return (
    <Router>
      <Suspense fallback={<Loader />}>
        <Routes>
          {/* Auth Routes */}
          <Route path="/auth" element={<AuthLayout />}>
            <Route path="login" element={<Login />} />
            <Route path="register" element={<Register />} />
            <Route path="verify-otp" element={<VerifyOTP />} />
            <Route path="" element={<Navigate to="/auth/login" replace />} />
          </Route>

          {/* Admin Routes - Protected */}
          <Route path="/admin" element={
            <ProtectedRoute>
              <AdminLayout />
            </ProtectedRoute>
          }>
            <Route path="dashboard" element={<Dashboard />} />
            <Route path="create-poll" element={<AdminCreatePoll />} />
            <Route path="polls/:id/results" element={<PollResults />} />
            <Route path="manage-polls" element={<ManagePolls />} />
            <Route path="heat-map" element={<HeatMap />} />
            <Route path="" element={<Navigate to="/admin/dashboard" replace />} />
          </Route>

          {/* Corporator Client Routes - Protected */}
          <Route path="/client" element={
            <ProtectedRoute>
              <ClientLayout />
            </ProtectedRoute>
          }>
            <Route path="dashboard" element={<ClientDashboard />} />
            <Route path="area-map" element={<ClientAreaMap />} />
            <Route path="create-poll" element={<CreatePoll />} />
            <Route path="" element={<Navigate to="/client/dashboard" replace />} />
          </Route>

          {/* User Routes - Protected */}
          <Route path="/feed" element={
            <ProtectedRoute>
              <MainLayout />
            </ProtectedRoute>
          }>
            <Route index element={<Feed />} />
            <Route path="polls/:id" element={<PollDetails />} />
          </Route>

          {/* Public Routes */}
          <Route path="/" element={<MainLayout />}>
            <Route index element={<Home />} />
            <Route path="about" element={<About />} />
            {/* Poll details is now protected */}
            <Route path="polls/:id" element={
              <ProtectedRoute>
                <PollDetails />
              </ProtectedRoute>
            } />
          </Route>
        </Routes>
      </Suspense>
    </Router>
  );
}

export default App;
