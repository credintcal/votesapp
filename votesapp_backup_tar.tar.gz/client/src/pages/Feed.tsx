import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';

// Mock poll data type
interface Poll {
  id: string;
  title: string;
  description: string;
  createdBy: string;
  createdAt: Date;
  totalVotes: number;
  options: string[];
}

const Feed: React.FC = () => {
  const [polls, setPolls] = useState<Poll[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    // Fetch polls from the server
    // This is mocked for now
    const fetchPolls = async () => {
      try {
        setLoading(true);
        
        // Mock data - in a real app, this would be an API call
        const mockPolls: Poll[] = [
          {
            id: '1',
            title: 'Should we increase education funding?',
            description: 'Poll about education budget allocation for the next fiscal year',
            createdBy: 'Education Minister',
            createdAt: new Date(2023, 3, 15),
            totalVotes: 1245,
            options: ['Yes', 'No', 'Only for public schools']
          },
          {
            id: '2',
            title: 'Do you support the new infrastructure plan?',
            description: 'Your opinion on the proposed 5-year infrastructure development plan',
            createdBy: 'Infrastructure Minister',
            createdAt: new Date(2023, 3, 10),
            totalVotes: 892,
            options: ['Strongly support', 'Support', 'Neutral', 'Oppose', 'Strongly oppose']
          },
          {
            id: '3',
            title: 'Priority for the next budget',
            description: 'What should be the main focus of the upcoming budget?',
            createdBy: 'Finance Minister',
            createdAt: new Date(2023, 3, 5),
            totalVotes: 2103,
            options: ['Healthcare', 'Education', 'Infrastructure', 'Defense', 'Environment']
          }
        ];
        
        setPolls(mockPolls);
        setLoading(false);
      } catch (err) {
        setError('Failed to load polls. Please try again later.');
        setLoading(false);
        console.error('Error fetching polls:', err);
      }
    };
    
    fetchPolls();
  }, []);

  // Extract user data from localStorage
  const userString = localStorage.getItem('user');
  const user = userString ? JSON.parse(userString) : { name: 'Voter' };

  return (
    <div className="max-w-4xl mx-auto p-4">
      <div className="mb-6 flex justify-between items-center">
        <h1 className="text-2xl font-bold text-secondary-800">Your Poll Feed</h1>
        <p className="text-primary-600">Welcome, {user.name}</p>
      </div>
      
      {error && (
        <div className="mb-4 p-3 bg-red-100 text-red-700 rounded-md">
          {error}
        </div>
      )}
      
      {loading ? (
        <div className="flex justify-center p-8">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
        </div>
      ) : (
        <>
          {polls.length === 0 ? (
            <div className="text-center py-8 bg-gray-50 rounded-lg">
              <p className="text-secondary-600">No polls available at the moment.</p>
              <p className="text-sm text-secondary-500 mt-2">Check back later for new polls.</p>
            </div>
          ) : (
            <div className="space-y-4">
              {polls.map((poll) => (
                <div 
                  key={poll.id} 
                  className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow"
                >
                  <h2 className="text-xl font-semibold text-secondary-800 mb-2">
                    {poll.title}
                  </h2>
                  <p className="text-secondary-600 mb-3">{poll.description}</p>
                  <div className="flex items-center text-sm text-secondary-500 mb-3">
                    <span className="mr-3">By: {poll.createdBy}</span>
                    <span>
                      {poll.createdAt.toLocaleDateString()} • {poll.totalVotes} votes
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <div className="flex space-x-2">
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                        {poll.options.length} options
                      </span>
                    </div>
                    <Link
                      to={`/polls/${poll.id}`}
                      className="inline-flex items-center px-3 py-2 border border-transparent text-sm leading-4 font-medium rounded-md text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
                    >
                      Vote Now
                    </Link>
                  </div>
                </div>
              ))}
            </div>
          )}
        </>
      )}
    </div>
  );
};

export default Feed; 