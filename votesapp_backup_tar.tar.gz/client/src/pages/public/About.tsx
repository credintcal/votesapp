import React from 'react';
import { Link } from 'react-router-dom';

const About: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold text-secondary-800 mb-6">About VOTESAPP</h1>
      
      <div className="bg-white rounded-lg shadow-md p-6 mb-8">
        <h2 className="text-xl font-semibold text-secondary-800 mb-4">Our Mission</h2>
        <p className="text-secondary-700 mb-4">
          VOTESAPP is dedicated to democratizing public opinion polling by providing a 100% free, 
          real-time platform for political parties and citizens to engage in meaningful dialogue 
          about important issues affecting their communities.
        </p>
        <p className="text-secondary-700 mb-4">
          Our mission is to empower citizens to make their voices heard while giving political 
          leaders valuable insights into public sentiment through transparent, secure, and 
          accessible technology.
        </p>
      </div>
      
      <div className="bg-white rounded-lg shadow-md p-6 mb-8">
        <h2 className="text-xl font-semibold text-secondary-800 mb-4">Key Features</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h3 className="text-lg font-medium text-primary-600 mb-2">Secure Authentication</h3>
            <p className="text-secondary-700">
              Our platform uses secure voter ID authentication with OTP verification to ensure
              that only legitimate voters can participate in polls.
            </p>
          </div>
          
          <div>
            <h3 className="text-lg font-medium text-primary-600 mb-2">Real-Time Results</h3>
            <p className="text-secondary-700">
              Watch as poll results update instantly, with detailed breakdowns and visualizations 
              to help understand public opinion.
            </p>
          </div>
          
          <div>
            <h3 className="text-lg font-medium text-primary-600 mb-2">Location Verification</h3>
            <p className="text-secondary-700">
              We verify voter locations to ensure accurate geographical representation in polling results,
              enabling heatmap visualizations and location-based insights.
            </p>
          </div>
          
          <div>
            <h3 className="text-lg font-medium text-primary-600 mb-2">Mobile-Friendly</h3>
            <p className="text-secondary-700">
              VOTESAPP is fully responsive and works on all devices, making it accessible to 
              voters wherever they are.
            </p>
          </div>
        </div>
      </div>
      
      <div className="bg-white rounded-lg shadow-md p-6 mb-8">
        <h2 className="text-xl font-semibold text-secondary-800 mb-4">Technology</h2>
        <p className="text-secondary-700 mb-4">
          VOTESAPP is built using only free, lifetime-maintainable technologies:
        </p>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <h3 className="text-lg font-medium text-primary-600 mb-2">Frontend</h3>
            <ul className="list-disc list-inside text-secondary-700 space-y-1">
              <li>React with TypeScript</li>
              <li>TailwindCSS for styling</li>
              <li>Leaflet.js with OpenStreetMap</li>
              <li>i18next for multi-language support</li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-medium text-primary-600 mb-2">Backend</h3>
            <ul className="list-disc list-inside text-secondary-700 space-y-1">
              <li>Node.js with Express</li>
              <li>Firebase Authentication</li>
              <li>Firebase Cloud Messaging</li>
              <li>Supabase (PostgreSQL)</li>
            </ul>
          </div>
        </div>
      </div>
      
      <div className="bg-primary-600 text-white rounded-lg p-6 text-center">
        <h2 className="text-2xl font-bold mb-4">Ready to join VOTESAPP?</h2>
        <p className="text-lg mb-6">
          Start making your voice heard on the issues that matter to your community.
        </p>
        <Link
          to="/auth/register"
          className="btn-secondary bg-white text-primary-600 hover:bg-primary-50 inline-block"
        >
          Register Now
        </Link>
      </div>
    </div>
  );
};

export default About; 