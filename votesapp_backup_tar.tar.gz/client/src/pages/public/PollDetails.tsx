import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';

interface Poll {
  id: string;
  title: string;
  description: string;
  options: string[];
  endDate: Date;
}

interface VoteResult {
  option: string;
  count: number;
  percentage: number;
}

const PollDetails: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  
  const [poll, setPoll] = useState<Poll | null>(null);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [hasVoted, setHasVoted] = useState(false);
  const [results, setResults] = useState<VoteResult[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState('');
  
  useEffect(() => {
    // Fetch poll details
    const fetchPoll = async () => {
      try {
        // TODO: Replace with actual API call
        // For now, using mock data
        setTimeout(() => {
          // Mock poll data based on ID
          const mockPoll: Poll = {
            id: id || '1',
            title: 'Local Infrastructure Development',
            description: 'Do you support the proposed road improvement project in your area?',
            options: ['Yes', 'No', 'Neutral'],
            endDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 days from now
          };
          
          setPoll(mockPoll);
          setIsLoading(false);
          
          // Check if user has already voted (for demo purposes)
          const hasUserVoted = localStorage.getItem(`voted_${id}`);
          if (hasUserVoted) {
            setHasVoted(true);
            fetchResults();
          }
        }, 1000);
      } catch (err) {
        console.error(`Error fetching poll with ID ${id}:`, err);
        setError('Failed to load poll details. Please try again later.');
        setIsLoading(false);
      }
    };
    
    fetchPoll();
  }, [id]);
  
  // Fetch results after voting
  const fetchResults = () => {
    // Mock results data
    const mockResults: VoteResult[] = [
      { option: 'Yes', count: 145, percentage: 58 },
      { option: 'No', count: 78, percentage: 31 },
      { option: 'Neutral', count: 27, percentage: 11 },
    ];
    
    setResults(mockResults);
  };
  
  const handleOptionSelect = (index: number) => {
    setSelectedOption(index);
  };
  
  const handleSubmitVote = async () => {
    if (selectedOption === null) return;
    
    setIsSubmitting(true);
    
    try {
      // TODO: Replace with actual API call
      // Mock submission
      setTimeout(() => {
        console.log(`Submitting vote for poll ${id}, option: ${selectedOption}`);
        
        // Store vote in localStorage for demo purposes
        localStorage.setItem(`voted_${id}`, 'true');
        
        setHasVoted(true);
        setIsSubmitting(false);
        
        // Fetch results after voting
        fetchResults();
      }, 1000);
    } catch (err) {
      console.error('Error submitting vote:', err);
      setError('Failed to submit your vote. Please try again.');
      setIsSubmitting(false);
    }
  };
  
  // Format date to readable string
  const formatDate = (date: Date): string => {
    return new Date(date).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };
  
  if (isLoading) {
    return (
      <div className="flex justify-center py-12">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-600"></div>
      </div>
    );
  }
  
  if (error) {
    return (
      <div className="bg-red-100 text-red-700 p-6 rounded-md">
        <p className="mb-4">{error}</p>
        <button 
          onClick={() => navigate('/')}
          className="btn-primary"
        >
          Return to Home
        </button>
      </div>
    );
  }
  
  if (!poll) {
    return (
      <div className="text-center py-12">
        <h2 className="text-2xl font-bold text-secondary-800 mb-4">Poll Not Found</h2>
        <p className="text-secondary-600 mb-6">The poll you're looking for doesn't exist or has been removed.</p>
        <button 
          onClick={() => navigate('/')}
          className="btn-primary"
        >
          Return to Home
        </button>
      </div>
    );
  }
  
  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white rounded-lg shadow-md p-6 mb-8">
        <h1 className="text-2xl font-bold text-secondary-800 mb-2">{poll.title}</h1>
        <p className="text-secondary-600 mb-6">{poll.description}</p>
        
        <div className="flex items-center text-sm text-secondary-500 mb-8">
          <div className="flex items-center mr-6">
            <svg className="h-5 w-5 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"></path>
            </svg>
            <span>Ends on: {formatDate(poll.endDate)}</span>
          </div>
          <div className="flex items-center">
            <svg className="h-5 w-5 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"></path>
            </svg>
            <span>250 votes so far</span>
          </div>
        </div>
        
        {hasVoted ? (
          <div>
            <div className="bg-green-50 border border-green-200 rounded-md p-4 mb-6">
              <div className="flex items-center text-green-700">
                <svg className="h-5 w-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                </svg>
                <span>Thank you for your vote!</span>
              </div>
            </div>
            
            <h2 className="text-xl font-semibold text-secondary-800 mb-4">Current Results</h2>
            
            <div className="space-y-4">
              {results.map((result, index) => (
                <div key={index} className="mb-4">
                  <div className="flex justify-between mb-1">
                    <span className="text-secondary-700">{result.option}</span>
                    <span className="text-secondary-700">{result.percentage}% ({result.count} votes)</span>
                  </div>
                  <div className="h-4 w-full bg-secondary-100 rounded-full overflow-hidden">
                    <div 
                      className={`h-full ${index === 0 ? 'bg-primary-500' : index === 1 ? 'bg-red-500' : 'bg-secondary-400'}`}
                      style={{ width: `${result.percentage}%` }}
                    ></div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ) : (
          <div>
            <h2 className="text-xl font-semibold text-secondary-800 mb-4">Cast Your Vote</h2>
            
            <div className="space-y-3 mb-6">
              {poll.options.map((option, index) => (
                <div key={index} className="relative">
                  <input
                    type="radio"
                    id={`option-${index}`}
                    name="poll-option"
                    className="absolute opacity-0 w-0 h-0"
                    checked={selectedOption === index}
                    onChange={() => handleOptionSelect(index)}
                  />
                  <label
                    htmlFor={`option-${index}`}
                    className={`block w-full p-4 border rounded-md cursor-pointer transition duration-200 
                      ${selectedOption === index 
                        ? 'bg-primary-50 border-primary-500 text-primary-700' 
                        : 'border-secondary-200 hover:border-primary-300'}`}
                  >
                    <div className="flex items-center">
                      <div className={`w-5 h-5 rounded-full border mr-3 flex items-center justify-center
                        ${selectedOption === index ? 'border-primary-500' : 'border-secondary-400'}`}
                      >
                        {selectedOption === index && (
                          <div className="w-3 h-3 rounded-full bg-primary-500"></div>
                        )}
                      </div>
                      <span>{option}</span>
                    </div>
                  </label>
                </div>
              ))}
            </div>
            
            <button
              onClick={handleSubmitVote}
              disabled={selectedOption === null || isSubmitting}
              className={`btn-primary w-full ${(selectedOption === null || isSubmitting) ? 'opacity-70 cursor-not-allowed' : ''}`}
            >
              {isSubmitting ? 'Submitting...' : 'Submit Vote'}
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default PollDetails; 