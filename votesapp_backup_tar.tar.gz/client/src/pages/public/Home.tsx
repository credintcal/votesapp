import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';

interface Poll {
  id: string;
  title: string;
  description: string;
  options: string[];
  endDate: Date;
}

const Home: React.FC = () => {
  const [polls, setPolls] = useState<Poll[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState('');
  
  useEffect(() => {
    // Fetch polls from API
    const fetchPolls = async () => {
      try {
        // TODO: Replace with actual API call
        // For now, using mock data
        setTimeout(() => {
          const mockPolls: Poll[] = [
            {
              id: '1',
              title: 'Local Infrastructure Development',
              description: 'Do you support the proposed road improvement project in your area?',
              options: ['Yes', 'No', 'Neutral'],
              endDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 days from now
            },
            {
              id: '2',
              title: 'Public Transportation Expansion',
              description: 'Should the city invest in expanding the public bus network?',
              options: ['Strongly Support', 'Support', 'Neutral', 'Oppose', 'Strongly Oppose'],
              endDate: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000), // 14 days from now
            },
            {
              id: '3',
              title: 'Community Park Renovation',
              description: 'Which feature would you like to see added to the central park?',
              options: ['Playground', 'Sports Fields', 'Walking Trails', 'Picnic Areas'],
              endDate: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000), // 5 days from now
            },
          ];
          
          setPolls(mockPolls);
          setIsLoading(false);
        }, 1000); // Simulate network delay
      } catch (err) {
        console.error('Error fetching polls:', err);
        setError('Failed to load polls. Please try again later.');
        setIsLoading(false);
      }
    };
    
    fetchPolls();
  }, []);
  
  // Format date to readable string
  const formatDate = (date: Date): string => {
    return new Date(date).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };
  
  return (
    <div>
      {/* Hero Section */}
      <section className="bg-primary-600 text-white rounded-lg p-8 mb-8">
        <div className="max-w-3xl mx-auto text-center">
          <h1 className="text-4xl font-bold mb-4">
            Your Voice Matters
          </h1>
          <p className="text-xl mb-6">
            VOTESAPP brings real-time public opinion polling to your community. 
            Vote on important issues and see results instantly.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Link
              to="/auth/register"
              className="btn-secondary bg-white text-primary-600 hover:bg-primary-50"
            >
              Register to Vote
            </Link>
            <Link
              to="/about"
              className="btn-secondary bg-primary-700 text-white border border-white hover:bg-primary-800"
            >
              Learn More
            </Link>
          </div>
        </div>
      </section>
      
      {/* Active Polls Section */}
      <section>
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-secondary-800">
            Active Polls
          </h2>
        </div>
        
        {isLoading ? (
          <div className="flex justify-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-600"></div>
          </div>
        ) : error ? (
          <div className="bg-red-100 text-red-700 p-4 rounded-md">
            {error}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {polls.map((poll) => (
              <div key={poll.id} className="card hover:shadow-lg transition duration-200">
                <h3 className="text-xl font-semibold text-secondary-800 mb-2">
                  {poll.title}
                </h3>
                <p className="text-secondary-600 mb-4">
                  {poll.description}
                </p>
                <div className="text-sm text-secondary-500 mb-4">
                  <p>Options: {poll.options.join(', ')}</p>
                  <p>Ends on: {formatDate(poll.endDate)}</p>
                </div>
                <Link
                  to={`/polls/${poll.id}`}
                  className="btn-primary inline-block"
                >
                  Vote Now
                </Link>
              </div>
            ))}
          </div>
        )}
      </section>
      
      {/* How It Works Section */}
      <section className="mt-12 bg-secondary-50 rounded-lg p-8">
        <h2 className="text-2xl font-bold text-secondary-800 mb-6 text-center">
          How It Works
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="text-center">
            <div className="bg-primary-100 text-primary-700 h-16 w-16 rounded-full flex items-center justify-center mx-auto mb-4">
              <svg className="h-8 w-8" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path>
              </svg>
            </div>
            <h3 className="text-lg font-semibold text-secondary-800 mb-2">1. Create an Account</h3>
            <p className="text-secondary-600">
              Register using your Voter ID and phone number. We verify your identity for secure voting.
            </p>
          </div>
          
          <div className="text-center">
            <div className="bg-primary-100 text-primary-700 h-16 w-16 rounded-full flex items-center justify-center mx-auto mb-4">
              <svg className="h-8 w-8" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
              </svg>
            </div>
            <h3 className="text-lg font-semibold text-secondary-800 mb-2">2. Vote on Polls</h3>
            <p className="text-secondary-600">
              Browse active polls and cast your vote securely. Your location is verified to ensure accurate representation.
            </p>
          </div>
          
          <div className="text-center">
            <div className="bg-primary-100 text-primary-700 h-16 w-16 rounded-full flex items-center justify-center mx-auto mb-4">
              <svg className="h-8 w-8" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"></path>
              </svg>
            </div>
            <h3 className="text-lg font-semibold text-secondary-800 mb-2">3. See Real-Time Results</h3>
            <p className="text-secondary-600">
              Watch as results update in real-time. View detailed breakdowns and heatmaps of public opinion.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home; 