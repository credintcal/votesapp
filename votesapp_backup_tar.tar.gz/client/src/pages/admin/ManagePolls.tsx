import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';

interface Poll {
  id: string;
  title: string;
  category: string;
  totalVotes: number;
  createdAt: Date;
  endDate: Date;
  isActive: boolean;
}

const ManagePolls: React.FC = () => {
  const [polls, setPolls] = useState<Poll[]>([]);
  const [filteredPolls, setFilteredPolls] = useState<Poll[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [categoryFilter, setCategoryFilter] = useState('all');
  
  useEffect(() => {
    // Fetch polls from API
    const fetchPolls = async () => {
      try {
        // TODO: Replace with actual API call
        // For now, using mock data
        setTimeout(() => {
          const mockPolls: Poll[] = [
            {
              id: '1',
              title: 'Local Infrastructure Development',
              category: 'Infrastructure',
              totalVotes: 250,
              createdAt: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000), // 10 days ago
              endDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 days from now
              isActive: true,
            },
            {
              id: '2',
              title: 'Public Transportation Expansion',
              category: 'Transportation',
              totalVotes: 187,
              createdAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000), // 7 days ago
              endDate: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000), // 14 days from now
              isActive: true,
            },
            {
              id: '3',
              title: 'Community Park Renovation',
              category: 'Recreation',
              totalVotes: 319,
              createdAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000), // 5 days ago
              endDate: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000), // 5 days from now
              isActive: true,
            },
            {
              id: '4',
              title: 'Public Safety Initiative',
              category: 'Public Safety',
              totalVotes: 128,
              createdAt: new Date(Date.now() - 20 * 24 * 60 * 60 * 1000), // 20 days ago
              endDate: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000), // 2 days ago
              isActive: false,
            },
            {
              id: '5',
              title: 'School Funding Proposal',
              category: 'Education',
              totalVotes: 276,
              createdAt: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000), // 30 days ago
              endDate: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000), // 10 days ago
              isActive: false,
            },
            {
              id: '6',
              title: 'Healthcare Access Survey',
              category: 'Health',
              totalVotes: 412,
              createdAt: new Date(Date.now() - 60 * 24 * 60 * 60 * 1000), // 60 days ago
              endDate: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000), // 30 days ago
              isActive: false,
            },
          ];
          
          setPolls(mockPolls);
          setFilteredPolls(mockPolls);
          setIsLoading(false);
        }, 1000);
      } catch (err) {
        console.error('Error fetching polls:', err);
        setError('Failed to load polls. Please try again later.');
        setIsLoading(false);
      }
    };
    
    fetchPolls();
  }, []);
  
  // Apply filters and search
  useEffect(() => {
    let result = [...polls];
    
    // Apply status filter
    if (statusFilter !== 'all') {
      const isActive = statusFilter === 'active';
      result = result.filter(poll => poll.isActive === isActive);
    }
    
    // Apply category filter
    if (categoryFilter !== 'all') {
      result = result.filter(poll => poll.category.toLowerCase() === categoryFilter);
    }
    
    // Apply search term
    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      result = result.filter(poll => 
        poll.title.toLowerCase().includes(term) || 
        poll.category.toLowerCase().includes(term)
      );
    }
    
    setFilteredPolls(result);
  }, [polls, searchTerm, statusFilter, categoryFilter]);
  
  // Format date to readable string
  const formatDate = (date: Date): string => {
    return new Date(date).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };
  
  const handleDeletePoll = (id: string) => {
    // TODO: Implement actual API call to delete poll
    if (window.confirm('Are you sure you want to delete this poll?')) {
      console.log('Deleting poll with ID:', id);
      
      // Mock deletion by filtering out the poll
      const updatedPolls = polls.filter(poll => poll.id !== id);
      setPolls(updatedPolls);
    }
  };
  
  if (isLoading) {
    return (
      <div className="flex justify-center py-12">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-600"></div>
      </div>
    );
  }
  
  if (error) {
    return (
      <div className="bg-red-100 text-red-700 p-6 rounded-md">
        {error}
      </div>
    );
  }
  
  const categories = ['Infrastructure', 'Transportation', 'Recreation', 'Public Safety', 'Education', 'Health', 'Economy', 'Environment'];
  
  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-secondary-800">Manage Polls</h1>
        <Link
          to="/admin/create-poll"
          className="btn-primary"
        >
          Create New Poll
        </Link>
      </div>
      
      {/* Filters Section */}
      <div className="bg-white rounded-lg shadow-md p-6 mb-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Search */}
          <div>
            <label htmlFor="search" className="block text-sm font-medium text-secondary-700 mb-1">
              Search
            </label>
            <input
              id="search"
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="input-field"
              placeholder="Search by title or category"
            />
          </div>
          
          {/* Status Filter */}
          <div>
            <label htmlFor="status" className="block text-sm font-medium text-secondary-700 mb-1">
              Status
            </label>
            <select
              id="status"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="input-field"
            >
              <option value="all">All Statuses</option>
              <option value="active">Active</option>
              <option value="ended">Ended</option>
            </select>
          </div>
          
          {/* Category Filter */}
          <div>
            <label htmlFor="category" className="block text-sm font-medium text-secondary-700 mb-1">
              Category
            </label>
            <select
              id="category"
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
              className="input-field"
            >
              <option value="all">All Categories</option>
              {categories.map((category, index) => (
                <option key={index} value={category.toLowerCase()}>
                  {category}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>
      
      {/* Polls Table */}
      <div className="bg-white rounded-lg shadow-md overflow-hidden">
        {filteredPolls.length === 0 ? (
          <div className="p-6 text-center text-secondary-500">
            No polls found matching your filters.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-left">
              <thead className="text-xs text-secondary-700 uppercase bg-secondary-50">
                <tr>
                  <th className="px-4 py-3">Title</th>
                  <th className="px-4 py-3">Category</th>
                  <th className="px-4 py-3">Created</th>
                  <th className="px-4 py-3">End Date</th>
                  <th className="px-4 py-3">Votes</th>
                  <th className="px-4 py-3">Status</th>
                  <th className="px-4 py-3">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredPolls.map((poll) => (
                  <tr key={poll.id} className="border-b hover:bg-secondary-50">
                    <td className="px-4 py-3 font-medium text-secondary-800">{poll.title}</td>
                    <td className="px-4 py-3">{poll.category}</td>
                    <td className="px-4 py-3">{formatDate(poll.createdAt)}</td>
                    <td className="px-4 py-3">{formatDate(poll.endDate)}</td>
                    <td className="px-4 py-3">{poll.totalVotes}</td>
                    <td className="px-4 py-3">
                      <span className={`px-2 py-1 rounded-full text-xs ${
                        poll.isActive 
                          ? 'bg-green-100 text-green-800' 
                          : 'bg-secondary-100 text-secondary-800'
                      }`}>
                        {poll.isActive ? 'Active' : 'Ended'}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex space-x-2">
                        <Link
                          to={`/admin/polls/${poll.id}/results`}
                          className="text-primary-600 hover:text-primary-800"
                          title="View Results"
                        >
                          <svg className="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"></path>
                          </svg>
                        </Link>
                        {poll.isActive && (
                          <button
                            onClick={() => handleDeletePoll(poll.id)}
                            className="text-red-600 hover:text-red-800"
                            title="Delete Poll"
                          >
                            <svg className="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path>
                            </svg>
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};

export default ManagePolls; 