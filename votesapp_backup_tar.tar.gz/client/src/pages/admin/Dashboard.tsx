import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';

interface PollSummary {
  id: string;
  title: string;
  totalVotes: number;
  endDate: Date;
  isActive: boolean;
}

interface VoteDistribution {
  label: string;
  value: number;
  color: string;
}

const Dashboard: React.FC = () => {
  const [recentPolls, setRecentPolls] = useState<PollSummary[]>([]);
  const [totalVotes, setTotalVotes] = useState(0);
  const [activePolls, setActivePolls] = useState(0);
  const [voteDistribution, setVoteDistribution] = useState<VoteDistribution[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  
  useEffect(() => {
    // Fetch dashboard data
    const fetchDashboardData = async () => {
      try {
        // TODO: Replace with actual API calls
        // Mock data for now
        setTimeout(() => {
          const mockRecentPolls: PollSummary[] = [
            {
              id: '1',
              title: 'Local Infrastructure Development',
              totalVotes: 250,
              endDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
              isActive: true,
            },
            {
              id: '2',
              title: 'Public Transportation Expansion',
              totalVotes: 187,
              endDate: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000),
              isActive: true,
            },
            {
              id: '3',
              title: 'Community Park Renovation',
              totalVotes: 319,
              endDate: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000),
              isActive: true,
            },
            {
              id: '4',
              title: 'Public Safety Initiative',
              totalVotes: 128,
              endDate: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
              isActive: false,
            },
          ];
          
          const mockVoteDistribution: VoteDistribution[] = [
            { label: 'Infrastructure', value: 250, color: 'bg-blue-500' },
            { label: 'Transportation', value: 187, color: 'bg-green-500' },
            { label: 'Recreation', value: 319, color: 'bg-purple-500' },
            { label: 'Public Safety', value: 128, color: 'bg-yellow-500' },
            { label: 'Education', value: 95, color: 'bg-red-500' },
          ];
          
          setRecentPolls(mockRecentPolls);
          setTotalVotes(979);
          setActivePolls(3);
          setVoteDistribution(mockVoteDistribution);
          setIsLoading(false);
        }, 1000);
      } catch (error) {
        console.error('Error fetching dashboard data:', error);
        setIsLoading(false);
      }
    };
    
    fetchDashboardData();
  }, []);
  
  // Format date to readable string
  const formatDate = (date: Date): string => {
    return new Date(date).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };
  
  if (isLoading) {
    return (
      <div className="flex justify-center py-12">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-600"></div>
      </div>
    );
  }
  
  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-secondary-800">Admin Dashboard</h1>
        <Link
          to="/admin/create-poll"
          className="btn-primary"
        >
          Create New Poll
        </Link>
      </div>
      
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-secondary-500 text-sm">Total Votes</p>
              <h3 className="text-3xl font-bold text-secondary-800">{totalVotes}</h3>
            </div>
            <div className="bg-primary-100 p-3 rounded-full">
              <svg className="h-6 w-6 text-primary-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01"></path>
              </svg>
            </div>
          </div>
          <p className="text-green-600 text-sm mt-2">+18% from last month</p>
        </div>
        
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-secondary-500 text-sm">Active Polls</p>
              <h3 className="text-3xl font-bold text-secondary-800">{activePolls}</h3>
            </div>
            <div className="bg-green-100 p-3 rounded-full">
              <svg className="h-6 w-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
              </svg>
            </div>
          </div>
          <p className="text-green-600 text-sm mt-2">All polls running smoothly</p>
        </div>
        
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-secondary-500 text-sm">Participating Voters</p>
              <h3 className="text-3xl font-bold text-secondary-800">428</h3>
            </div>
            <div className="bg-purple-100 p-3 rounded-full">
              <svg className="h-6 w-6 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"></path>
              </svg>
            </div>
          </div>
          <p className="text-green-600 text-sm mt-2">+32 new voters this week</p>
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Recent Polls */}
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-xl font-semibold text-secondary-800 mb-4">Recent Polls</h2>
          
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-left">
              <thead className="text-xs text-secondary-700 uppercase bg-secondary-50">
                <tr>
                  <th className="px-4 py-3 rounded-tl-lg">Poll Title</th>
                  <th className="px-4 py-3">Votes</th>
                  <th className="px-4 py-3">End Date</th>
                  <th className="px-4 py-3 rounded-tr-lg">Status</th>
                </tr>
              </thead>
              <tbody>
                {recentPolls.map((poll) => (
                  <tr key={poll.id} className="border-b hover:bg-secondary-50">
                    <td className="px-4 py-3">
                      <Link to={`/admin/polls/${poll.id}/results`} className="text-primary-600 hover:text-primary-800">
                        {poll.title}
                      </Link>
                    </td>
                    <td className="px-4 py-3">{poll.totalVotes}</td>
                    <td className="px-4 py-3">{formatDate(poll.endDate)}</td>
                    <td className="px-4 py-3">
                      <span className={`px-2 py-1 rounded-full text-xs ${
                        poll.isActive 
                          ? 'bg-green-100 text-green-800' 
                          : 'bg-secondary-100 text-secondary-800'
                      }`}>
                        {poll.isActive ? 'Active' : 'Ended'}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          
          <div className="mt-4 text-right">
            <Link to="/admin/manage-polls" className="text-primary-600 hover:text-primary-800 text-sm">
              View All Polls →
            </Link>
          </div>
        </div>
        
        {/* Vote Distribution */}
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-xl font-semibold text-secondary-800 mb-4">Vote Distribution by Category</h2>
          
          <div className="space-y-4">
            {voteDistribution.map((item, index) => (
              <div key={index}>
                <div className="flex justify-between mb-1">
                  <span className="text-secondary-700">{item.label}</span>
                  <span className="text-secondary-700">{item.value} votes</span>
                </div>
                <div className="h-4 w-full bg-secondary-100 rounded-full overflow-hidden">
                  <div 
                    className={`h-full ${item.color}`}
                    style={{ width: `${(item.value / totalVotes) * 100}%` }}
                  ></div>
                </div>
              </div>
            ))}
          </div>
          
          <div className="mt-6">
            <h3 className="text-sm font-medium text-secondary-600 mb-2">Summary</h3>
            <p className="text-secondary-600 text-sm">
              Based on the current data, Recreation category polls are receiving the most engagement,
              followed by Infrastructure and Transportation initiatives.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard; 