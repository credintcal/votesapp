import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';

interface Poll {
  id: string;
  title: string;
  description: string;
  category: string;
  options: string[];
  totalVotes: number;
  createdAt: Date;
  endDate: Date;
  isActive: boolean;
}

interface VoteResult {
  option: string;
  count: number;
  percentage: number;
  color: string;
}

interface VoterData {
  option: string; 
  timestamp: Date;
  voterLocation: {
    latitude: number;
    longitude: number;
  };
}

interface VoteByTime {
  date: string;
  count: number;
}

const PollResults: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  
  const [poll, setPoll] = useState<Poll | null>(null);
  const [results, setResults] = useState<VoteResult[]>([]);
  const [voterData, setVoterData] = useState<VoterData[]>([]);
  const [votesByTime, setVotesByTime] = useState<VoteByTime[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState('');
  
  // Colors for chart
  const chartColors = ['bg-blue-500', 'bg-green-500', 'bg-yellow-500', 'bg-red-500', 'bg-purple-500', 'bg-indigo-500'];
  
  useEffect(() => {
    // Fetch poll and results data
    const fetchPollData = async () => {
      try {
        // TODO: Replace with actual API calls
        // For now, using mock data
        setTimeout(() => {
          const mockPoll: Poll = {
            id: id || '1',
            title: 'Local Infrastructure Development',
            description: 'Do you support the proposed road improvement project in your area?',
            category: 'Infrastructure',
            options: ['Yes', 'No', 'Neutral'],
            totalVotes: 250,
            createdAt: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000), // 10 days ago
            endDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 days from now
            isActive: true,
          };
          
          // Mock results data
          const mockResults: VoteResult[] = [
            { option: 'Yes', count: 145, percentage: 58, color: chartColors[0] },
            { option: 'No', count: 78, percentage: 31, color: chartColors[1] },
            { option: 'Neutral', count: 27, percentage: 11, color: chartColors[2] },
          ];
          
          // Mock voter locations data
          const mockVoterData: VoterData[] = Array(20).fill(null).map((_, index) => ({
            option: mockResults[Math.floor(Math.random() * mockResults.length)].option,
            timestamp: new Date(Date.now() - Math.floor(Math.random() * 10) * 24 * 60 * 60 * 1000),
            voterLocation: {
              latitude: 51.505 + (Math.random() - 0.5) * 0.1,
              longitude: -0.09 + (Math.random() - 0.5) * 0.1,
            }
          }));
          
          // Mock votes by time data
          const mockVotesByTime: VoteByTime[] = [
            { date: '2023-03-01', count: 35 },
            { date: '2023-03-02', count: 28 },
            { date: '2023-03-03', count: 42 },
            { date: '2023-03-04', count: 37 },
            { date: '2023-03-05', count: 15 },
            { date: '2023-03-06', count: 25 },
            { date: '2023-03-07', count: 68 },
          ];
          
          setPoll(mockPoll);
          setResults(mockResults);
          setVoterData(mockVoterData);
          setVotesByTime(mockVotesByTime);
          setIsLoading(false);
        }, 1500);
      } catch (err) {
        console.error(`Error fetching poll data for ID ${id}:`, err);
        setError('Failed to load poll results. Please try again later.');
        setIsLoading(false);
      }
    };
    
    fetchPollData();
  }, [id]);
  
  // Format date to readable string
  const formatDate = (date: Date): string => {
    return new Date(date).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };
  
  // Generate a downloadable report
  const generateReport = () => {
    if (!poll) return;
    
    // TODO: Implement actual report generation
    // For now, just alert a message
    alert('Report generation feature will be implemented in the future.');
  };
  
  if (isLoading) {
    return (
      <div className="flex justify-center py-12">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-600"></div>
      </div>
    );
  }
  
  if (error) {
    return (
      <div className="bg-red-100 text-red-700 p-6 rounded-md">
        <p className="mb-4">{error}</p>
        <button 
          onClick={() => navigate('/admin/manage-polls')}
          className="btn-primary"
        >
          Return to Polls
        </button>
      </div>
    );
  }
  
  if (!poll) {
    return (
      <div className="text-center py-12">
        <h2 className="text-2xl font-bold text-secondary-800 mb-4">Poll Not Found</h2>
        <p className="text-secondary-600 mb-6">The poll you're looking for doesn't exist or has been removed.</p>
        <button 
          onClick={() => navigate('/admin/manage-polls')}
          className="btn-primary"
        >
          Return to Polls
        </button>
      </div>
    );
  }
  
  return (
    <div>
      <div className="flex flex-wrap justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold text-secondary-800">{poll.title}</h1>
          <p className="text-secondary-600">Results Overview</p>
        </div>
        <div className="flex space-x-3 mt-3 sm:mt-0">
          <button
            onClick={generateReport}
            className="btn-secondary flex items-center"
          >
            <svg className="h-5 w-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"></path>
            </svg>
            Download Report
          </button>
          <button
            onClick={() => navigate('/admin/manage-polls')}
            className="btn-primary"
          >
            Back to Polls
          </button>
        </div>
      </div>
      
      {/* Poll Info Card */}
      <div className="bg-white rounded-lg shadow-md p-6 mb-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h3 className="text-lg font-semibold text-secondary-800 mb-2">Poll Details</h3>
            <p className="text-secondary-600 mb-4">{poll.description}</p>
            
            <div className="grid grid-cols-2 gap-x-6 gap-y-2 text-sm">
              <div>
                <span className="text-secondary-500">Category:</span>
                <p className="font-medium text-secondary-800">{poll.category}</p>
              </div>
              <div>
                <span className="text-secondary-500">Total Votes:</span>
                <p className="font-medium text-secondary-800">{poll.totalVotes}</p>
              </div>
              <div>
                <span className="text-secondary-500">Created On:</span>
                <p className="font-medium text-secondary-800">{formatDate(poll.createdAt)}</p>
              </div>
              <div>
                <span className="text-secondary-500">End Date:</span>
                <p className="font-medium text-secondary-800">{formatDate(poll.endDate)}</p>
              </div>
              <div>
                <span className="text-secondary-500">Status:</span>
                <p className={`font-medium ${poll.isActive ? 'text-green-600' : 'text-secondary-600'}`}>
                  {poll.isActive ? 'Active' : 'Ended'}
                </p>
              </div>
            </div>
          </div>
          
          {/* Vote Results */}
          <div>
            <h3 className="text-lg font-semibold text-secondary-800 mb-4">Vote Distribution</h3>
            <div className="space-y-4">
              {results.map((result, index) => (
                <div key={index} className="mb-4">
                  <div className="flex justify-between mb-1">
                    <span className="text-secondary-700">{result.option}</span>
                    <span className="text-secondary-700">{result.percentage}% ({result.count} votes)</span>
                  </div>
                  <div className="h-4 w-full bg-secondary-100 rounded-full overflow-hidden">
                    <div 
                      className={`h-full ${result.color}`}
                      style={{ width: `${result.percentage}%` }}
                    ></div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Votes by Time */}
        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-lg font-semibold text-secondary-800 mb-4">Votes Over Time</h3>
          
          <div className="h-64 flex items-end space-x-1 pt-6">
            {votesByTime.map((item, index) => {
              const maxCount = Math.max(...votesByTime.map(v => v.count));
              const height = (item.count / maxCount) * 100;
              
              return (
                <div key={index} className="flex flex-col items-center flex-1">
                  <div 
                    className="w-full bg-primary-500 hover:bg-primary-600 transition" 
                    style={{ height: `${height}%` }}
                    title={`${item.date}: ${item.count} votes`}
                  ></div>
                  <div className="text-xs text-secondary-500 mt-1 transform -rotate-45 origin-top-left">
                    {item.date.substring(5)}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
        
        {/* Voter Demographics */}
        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-lg font-semibold text-secondary-800 mb-4">Geographic Distribution</h3>
          
          <div className="bg-secondary-100 rounded-md p-4 h-64 flex items-center justify-center">
            <div className="text-center">
              <svg className="h-12 w-12 text-secondary-400 mx-auto mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7"></path>
              </svg>
              <p className="text-secondary-600">
                Interactive map will be implemented in the future to show geographic distribution of votes.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PollResults; 