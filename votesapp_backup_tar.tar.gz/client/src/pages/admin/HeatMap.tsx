import React, { useState, useEffect } from 'react';

interface AreaData {
  id: string;
  name: string;
  district: string;
  positiveVotes: number;
  negativeVotes: number;
  totalVotes: number;
  coordinates: {
    lat: number;
    lng: number;
  };
}

interface PollStat {
  id: string;
  title: string;
  totalVotes: number;
}

const HeatMap: React.FC = () => {
  const [areas, setAreas] = useState<AreaData[]>([]);
  const [selectedPoll, setSelectedPoll] = useState<string>('1');
  const [polls, setPolls] = useState<PollStat[]>([]);
  const [loading, setLoading] = useState(true);
  const [timeframe, setTimeframe] = useState('7days');
  
  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        
        // Mock polls data
        const pollsData: PollStat[] = [
          { id: '1', title: 'Infrastructure Development Plan', totalVotes: 3254 },
          { id: '2', title: 'Education Budget Allocation', totalVotes: 2876 },
          { id: '3', title: 'Healthcare Services Improvement', totalVotes: 1987 }
        ];
        
        // Mock areas data
        const areasData: AreaData[] = [
          {
            id: '1',
            name: 'North District',
            district: 'Northern',
            positiveVotes: 850,
            negativeVotes: 320,
            totalVotes: 1170,
            coordinates: { lat: 17.45, lng: 78.35 }
          },
          {
            id: '2',
            name: 'Central Zone',
            district: 'Central',
            positiveVotes: 240,
            negativeVotes: 780,
            totalVotes: 1020,
            coordinates: { lat: 17.41, lng: 78.42 }
          },
          {
            id: '3',
            name: 'Eastern Suburbs',
            district: 'Eastern',
            positiveVotes: 520,
            negativeVotes: 310,
            totalVotes: 830,
            coordinates: { lat: 17.44, lng: 78.48 }
          },
          {
            id: '4',
            name: 'Western Hills',
            district: 'Western',
            positiveVotes: 610,
            negativeVotes: 230,
            totalVotes: 840,
            coordinates: { lat: 17.42, lng: 78.32 }
          },
          {
            id: '5',
            name: 'Southern Region',
            district: 'Southern',
            positiveVotes: 320,
            negativeVotes: 690,
            totalVotes: 1010,
            coordinates: { lat: 17.36, lng: 78.40 }
          }
        ];
        
        setPolls(pollsData);
        setAreas(areasData);
        setLoading(false);
      } catch (error) {
        console.error('Error fetching data:', error);
        setLoading(false);
      }
    };
    
    fetchData();
  }, []);
  
  // When timeframe changes, we would normally fetch new data
  useEffect(() => {
    // Simulating data refresh
    console.log(`Fetching data for timeframe: ${timeframe}`);
    // In a real app, would call fetchData() with new parameters
  }, [timeframe]);
  
  const getAreaColorClass = (area: AreaData) => {
    const ratio = area.positiveVotes / (area.positiveVotes + area.negativeVotes);
    
    if (ratio >= 0.7) return 'bg-green-600'; // Strong support
    if (ratio >= 0.55) return 'bg-green-400'; // Moderate support
    if (ratio >= 0.45) return 'bg-yellow-400'; // Neutral
    if (ratio >= 0.3) return 'bg-red-400'; // Moderate opposition
    return 'bg-red-600'; // Strong opposition
  };
  
  const calculateOverallSentiment = () => {
    const totalPositive = areas.reduce((sum, area) => sum + area.positiveVotes, 0);
    const totalNegative = areas.reduce((sum, area) => sum + area.negativeVotes, 0);
    const totalVotes = totalPositive + totalNegative;
    
    const positivePercentage = Math.round((totalPositive / totalVotes) * 100);
    const negativePercentage = Math.round((totalNegative / totalVotes) * 100);
    
    return { positivePercentage, negativePercentage, totalVotes };
  };
  
  const { positivePercentage, negativePercentage, totalVotes } = calculateOverallSentiment();
  
  return (
    <div className="container mx-auto px-4 py-6">
      <h1 className="text-2xl font-bold text-secondary-800 mb-6">Real-Time Opinion Heat Map</h1>
      
      {/* Controls */}
      <div className="bg-white p-4 rounded-lg shadow mb-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between">
          <div className="mb-4 md:mb-0">
            <label htmlFor="poll-select" className="block text-sm font-medium text-secondary-700 mb-1">
              Select Poll
            </label>
            <select
              id="poll-select"
              value={selectedPoll}
              onChange={(e) => setSelectedPoll(e.target.value)}
              className="input-field w-full md:w-72"
            >
              {polls.map(poll => (
                <option key={poll.id} value={poll.id}>
                  {poll.title} ({poll.totalVotes} votes)
                </option>
              ))}
            </select>
          </div>
          
          <div className="flex space-x-2">
            <button
              onClick={() => setTimeframe('24h')}
              className={`px-3 py-1 rounded-md text-sm ${
                timeframe === '24h' 
                  ? 'bg-primary-600 text-white' 
                  : 'bg-gray-100 hover:bg-gray-200 text-secondary-700'
              }`}
            >
              24h
            </button>
            <button
              onClick={() => setTimeframe('7days')}
              className={`px-3 py-1 rounded-md text-sm ${
                timeframe === '7days' 
                  ? 'bg-primary-600 text-white' 
                  : 'bg-gray-100 hover:bg-gray-200 text-secondary-700'
              }`}
            >
              7 days
            </button>
            <button
              onClick={() => setTimeframe('30days')}
              className={`px-3 py-1 rounded-md text-sm ${
                timeframe === '30days' 
                  ? 'bg-primary-600 text-white' 
                  : 'bg-gray-100 hover:bg-gray-200 text-secondary-700'
              }`}
            >
              30 days
            </button>
            <button
              onClick={() => setTimeframe('all')}
              className={`px-3 py-1 rounded-md text-sm ${
                timeframe === 'all' 
                  ? 'bg-primary-600 text-white' 
                  : 'bg-gray-100 hover:bg-gray-200 text-secondary-700'
              }`}
            >
              All time
            </button>
          </div>
        </div>
      </div>
      
      {/* Overall sentiment */}
      <div className="bg-white p-4 rounded-lg shadow mb-6">
        <h2 className="text-lg font-medium text-secondary-800 mb-3">Overall Sentiment</h2>
        <div className="flex items-center mb-3">
          <div className="w-full bg-gray-200 rounded-full h-4">
            <div 
              className="bg-green-500 h-4 rounded-full" 
              style={{ width: `${positivePercentage}%` }}
            ></div>
          </div>
          <span className="ml-3 text-sm font-medium">{positivePercentage}% Support</span>
        </div>
        <div className="flex items-center">
          <div className="w-full bg-gray-200 rounded-full h-4">
            <div 
              className="bg-red-500 h-4 rounded-full" 
              style={{ width: `${negativePercentage}%` }}
            ></div>
          </div>
          <span className="ml-3 text-sm font-medium">{negativePercentage}% Against</span>
        </div>
        <div className="mt-2 text-sm text-secondary-600">
          Based on {totalVotes} votes from all areas
        </div>
      </div>
      
      {/* Map visualization */}
      <div className="bg-white p-4 rounded-lg shadow mb-6">
        <h2 className="text-lg font-medium text-secondary-800 mb-3">Geographic Distribution</h2>
        
        {loading ? (
          <div className="flex justify-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-500"></div>
          </div>
        ) : (
          <div className="relative">
            {/* This would be replaced with an actual map component in production */}
            <div className="aspect-w-16 aspect-h-9 bg-gray-100 rounded-lg overflow-hidden">
              <div className="p-12 grid grid-cols-3 gap-6 w-full h-full">
                {areas.map((area) => (
                  <div
                    key={area.id}
                    className={`${getAreaColorClass(area)} rounded-lg p-4 flex flex-col justify-between text-white shadow-lg transform transition-transform hover:scale-105`}
                    style={{
                      position: 'absolute',
                      top: `${Math.random() * 60 + 10}%`,
                      left: `${Math.random() * 60 + 10}%`,
                      width: '120px',
                      height: '110px',
                    }}
                  >
                    <div>
                      <h3 className="font-bold text-sm">{area.name}</h3>
                      <p className="text-xs opacity-90">{area.district}</p>
                    </div>
                    <div className="text-sm">
                      <div className="flex justify-between items-center">
                        <span>👍</span>
                        <span>{area.positiveVotes}</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span>👎</span>
                        <span>{area.negativeVotes}</span>
                      </div>
                    </div>
                  </div>
                ))}
                <div className="col-span-3 flex items-center justify-center text-lg text-secondary-400">
                  In a production environment, this would be an interactive map using Leaflet or Google Maps
                </div>
              </div>
            </div>
            
            {/* Legend */}
            <div className="mt-4 flex items-center justify-center space-x-4">
              <div className="flex items-center">
                <div className="w-4 h-4 bg-green-600 rounded mr-2"></div>
                <span className="text-sm">Strong Support</span>
              </div>
              <div className="flex items-center">
                <div className="w-4 h-4 bg-green-400 rounded mr-2"></div>
                <span className="text-sm">Moderate Support</span>
              </div>
              <div className="flex items-center">
                <div className="w-4 h-4 bg-yellow-400 rounded mr-2"></div>
                <span className="text-sm">Neutral</span>
              </div>
              <div className="flex items-center">
                <div className="w-4 h-4 bg-red-400 rounded mr-2"></div>
                <span className="text-sm">Moderate Opposition</span>
              </div>
              <div className="flex items-center">
                <div className="w-4 h-4 bg-red-600 rounded mr-2"></div>
                <span className="text-sm">Strong Opposition</span>
              </div>
            </div>
          </div>
        )}
      </div>
      
      {/* Detailed area breakdown */}
      <div className="bg-white rounded-lg shadow overflow-hidden">
        <h2 className="text-lg font-medium text-secondary-800 p-4 border-b">Area Breakdown</h2>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-secondary-500 uppercase tracking-wider">
                  Area
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-secondary-500 uppercase tracking-wider">
                  District
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-secondary-500 uppercase tracking-wider">
                  Support
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-secondary-500 uppercase tracking-wider">
                  Against
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-secondary-500 uppercase tracking-wider">
                  Total Votes
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-secondary-500 uppercase tracking-wider">
                  Sentiment
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {areas.map((area) => (
                <tr key={area.id}>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-secondary-800">
                    {area.name}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-secondary-600">
                    {area.district}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-green-600 font-medium">
                    {area.positiveVotes} ({Math.round((area.positiveVotes / area.totalVotes) * 100)}%)
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-red-600 font-medium">
                    {area.negativeVotes} ({Math.round((area.negativeVotes / area.totalVotes) * 100)}%)
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-secondary-600">
                    {area.totalVotes}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="w-24 bg-gray-200 rounded-full h-2.5">
                      <div 
                        className={`${getAreaColorClass(area)} h-2.5 rounded-full`}
                        style={{ width: `${Math.round((area.positiveVotes / area.totalVotes) * 100)}%` }}
                      ></div>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default HeatMap; 