import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

interface PollOption {
  id: string;
  text: string;
}

const CreatePoll: React.FC = () => {
  const navigate = useNavigate();
  
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    category: '',
    endDate: '',
  });
  
  const [options, setOptions] = useState<PollOption[]>([
    { id: '1', text: '' },
    { id: '2', text: '' },
  ]);
  
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };
  
  const handleOptionChange = (id: string, value: string) => {
    setOptions(prevOptions => 
      prevOptions.map(option => 
        option.id === id ? { ...option, text: value } : option
      )
    );
  };
  
  const addOption = () => {
    const newId = (options.length + 1).toString();
    setOptions(prev => [...prev, { id: newId, text: '' }]);
  };
  
  const removeOption = (id: string) => {
    if (options.length <= 2) {
      setError('A poll must have at least 2 options');
      return;
    }
    
    setOptions(prev => prev.filter(option => option.id !== id));
    setError('');
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Simple validation
    if (!formData.title || !formData.description || !formData.category || !formData.endDate) {
      setError('Please fill in all required fields');
      return;
    }
    
    // Check if all options have text
    const emptyOptions = options.filter(option => !option.text.trim());
    if (emptyOptions.length > 0) {
      setError('Please fill in all poll options');
      return;
    }
    
    // Check if endDate is in the future
    const selectedEndDate = new Date(formData.endDate);
    if (selectedEndDate <= new Date()) {
      setError('End date must be in the future');
      return;
    }
    
    setIsSubmitting(true);
    setError('');
    
    try {
      // TODO: Replace with actual API call
      // Mock submission for now
      setTimeout(() => {
        console.log('Submitting poll:', {
          ...formData,
          options: options.map(opt => opt.text)
        });
        
        setSuccess('Poll created successfully!');
        setIsSubmitting(false);
        
        // Redirect to polls list after 2 seconds
        setTimeout(() => {
          navigate('/admin/manage-polls');
        }, 2000);
      }, 1500);
    } catch (err) {
      console.error('Error creating poll:', err);
      setError('Failed to create poll. Please try again.');
      setIsSubmitting(false);
    }
  };
  
  return (
    <div className="max-w-3xl mx-auto">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-secondary-800">Create New Poll</h1>
      </div>
      
      <div className="bg-white rounded-lg shadow-md p-6">
        {error && (
          <div className="mb-6 p-4 bg-red-100 text-red-700 rounded-md text-sm">
            {error}
          </div>
        )}
        
        {success && (
          <div className="mb-6 p-4 bg-green-100 text-green-700 rounded-md text-sm">
            {success}
          </div>
        )}
        
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Poll Title */}
          <div>
            <label htmlFor="title" className="block text-sm font-medium text-secondary-700 mb-1">
              Poll Title <span className="text-red-500">*</span>
            </label>
            <input
              id="title"
              name="title"
              type="text"
              value={formData.title}
              onChange={handleChange}
              className="input-field"
              placeholder="Enter poll title"
              maxLength={100}
            />
          </div>
          
          {/* Poll Description */}
          <div>
            <label htmlFor="description" className="block text-sm font-medium text-secondary-700 mb-1">
              Description <span className="text-red-500">*</span>
            </label>
            <textarea
              id="description"
              name="description"
              rows={3}
              value={formData.description}
              onChange={handleChange}
              className="input-field"
              placeholder="Enter poll description"
              maxLength={500}
            />
          </div>
          
          {/* Poll Category */}
          <div>
            <label htmlFor="category" className="block text-sm font-medium text-secondary-700 mb-1">
              Category <span className="text-red-500">*</span>
            </label>
            <select
              id="category"
              name="category"
              value={formData.category}
              onChange={handleChange}
              className="input-field"
            >
              <option value="">Select a category</option>
              <option value="infrastructure">Infrastructure</option>
              <option value="transportation">Transportation</option>
              <option value="recreation">Recreation</option>
              <option value="public-safety">Public Safety</option>
              <option value="education">Education</option>
              <option value="health">Health</option>
              <option value="economy">Economy</option>
              <option value="environment">Environment</option>
            </select>
          </div>
          
          {/* End Date */}
          <div>
            <label htmlFor="endDate" className="block text-sm font-medium text-secondary-700 mb-1">
              End Date <span className="text-red-500">*</span>
            </label>
            <input
              id="endDate"
              name="endDate"
              type="date"
              value={formData.endDate}
              onChange={handleChange}
              className="input-field"
              min={new Date().toISOString().split('T')[0]}
            />
          </div>
          
          {/* Poll Options */}
          <div>
            <div className="flex justify-between items-center mb-2">
              <label className="block text-sm font-medium text-secondary-700">
                Poll Options <span className="text-red-500">*</span>
              </label>
              <button
                type="button"
                onClick={addOption}
                className="text-sm text-primary-600 hover:text-primary-800"
              >
                + Add Option
              </button>
            </div>
            
            <div className="space-y-3">
              {options.map((option, index) => (
                <div key={option.id} className="flex items-center space-x-2">
                  <input
                    type="text"
                    value={option.text}
                    onChange={(e) => handleOptionChange(option.id, e.target.value)}
                    className="input-field"
                    placeholder={`Option ${index + 1}`}
                  />
                  <button
                    type="button"
                    onClick={() => removeOption(option.id)}
                    className="text-red-500 hover:text-red-700"
                  >
                    <svg className="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path>
                    </svg>
                  </button>
                </div>
              ))}
            </div>
          </div>
          
          {/* Submit Button */}
          <div className="flex items-center justify-end space-x-3 pt-4">
            <button
              type="button"
              onClick={() => navigate('/admin/manage-polls')}
              className="btn-secondary"
              disabled={isSubmitting}
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className={`btn-primary ${isSubmitting ? 'opacity-70 cursor-not-allowed' : ''}`}
            >
              {isSubmitting ? 'Creating...' : 'Create Poll'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default CreatePoll; 