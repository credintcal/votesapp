import React, { useState, useEffect } from 'react';

interface VotingData {
  id: string;
  areaName: string;
  positiveVotes: number;
  negativeVotes: number;
  totalVotes: number;
  coordinates: {
    lat: number;
    lng: number;
  };
}

const AreaMap: React.FC = () => {
  const [selectedPoll, setSelectedPoll] = useState<string>('1');
  const [votingData, setVotingData] = useState<VotingData[]>([]);
  const [loading, setLoading] = useState(true);
  
  // Get client info from localStorage
  const clientString = localStorage.getItem('user');
  const client = clientString ? JSON.parse(clientString) : { name: 'Corporator', division: 'Local Area' };
  
  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        
        // Mock data - in a real app, this would be an API call
        const mockData: VotingData[] = [
          {
            id: '1',
            areaName: 'North Sector',
            positiveVotes: 245,
            negativeVotes: 112,
            totalVotes: 357,
            coordinates: { lat: 17.45, lng: 78.35 }
          },
          {
            id: '2',
            areaName: 'Central Market',
            positiveVotes: 187,
            negativeVotes: 203,
            totalVotes: 390,
            coordinates: { lat: 17.41, lng: 78.42 }
          },
          {
            id: '3',
            areaName: 'East Residential',
            positiveVotes: 312,
            negativeVotes: 145,
            totalVotes: 457,
            coordinates: { lat: 17.44, lng: 78.48 }
          },
          {
            id: '4',
            areaName: 'West Hills',
            positiveVotes: 178,
            negativeVotes: 89,
            totalVotes: 267,
            coordinates: { lat: 17.42, lng: 78.32 }
          }
        ];
        
        setVotingData(mockData);
        setLoading(false);
      } catch (error) {
        console.error('Error fetching area data:', error);
        setLoading(false);
      }
    };
    
    fetchData();
  }, [selectedPoll]);
  
  // Calculate overall sentiment
  const calculateOverallSentiment = () => {
    const totalPositive = votingData.reduce((sum, area) => sum + area.positiveVotes, 0);
    const totalNegative = votingData.reduce((sum, area) => sum + area.negativeVotes, 0);
    const totalVotes = totalPositive + totalNegative;
    
    const positivePercentage = Math.round((totalPositive / totalVotes) * 100) || 0;
    
    return {
      positivePercentage,
      negativePercentage: 100 - positivePercentage,
      totalVotes
    };
  };
  
  const { positivePercentage, negativePercentage, totalVotes } = calculateOverallSentiment();
  
  // Determine color class based on sentiment
  const getColorClass = (area: VotingData) => {
    const ratio = area.positiveVotes / area.totalVotes;
    
    if (ratio >= 0.6) return 'bg-green-500';
    if (ratio >= 0.5) return 'bg-green-400';
    if (ratio >= 0.4) return 'bg-yellow-400';
    if (ratio >= 0.3) return 'bg-red-400';
    return 'bg-red-500';
  };
  
  return (
    <div className="container mx-auto px-4 py-6">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold text-secondary-800">Area Map</h1>
          <p className="text-secondary-600">{client.division}</p>
        </div>
        
        <div>
          <label htmlFor="poll-select" className="block text-sm font-medium text-secondary-700 mb-1">
            Select Poll
          </label>
          <select 
            id="poll-select" 
            value={selectedPoll}
            onChange={(e) => setSelectedPoll(e.target.value)}
            className="input-field w-64"
          >
            <option value="1">Road Development Project (357 votes)</option>
            <option value="2">Local Park Renovation (245 votes)</option>
            <option value="3">Public Transport Improvement (189 votes)</option>
          </select>
        </div>
      </div>
      
      {/* Overall Sentiment */}
      <div className="bg-white p-4 rounded-lg shadow mb-6">
        <h2 className="text-lg font-medium text-secondary-800 mb-3">Overall Area Sentiment</h2>
        <div className="flex items-center mb-3">
          <div className="w-full bg-gray-200 rounded-full h-4">
            <div 
              className="bg-green-500 h-4 rounded-full" 
              style={{ width: `${positivePercentage}%` }}
            ></div>
          </div>
          <span className="ml-3 text-sm font-medium">{positivePercentage}% Support</span>
        </div>
        <div className="flex items-center">
          <div className="w-full bg-gray-200 rounded-full h-4">
            <div 
              className="bg-red-500 h-4 rounded-full" 
              style={{ width: `${negativePercentage}%` }}
            ></div>
          </div>
          <span className="ml-3 text-sm font-medium">{negativePercentage}% Against</span>
        </div>
        <div className="mt-2 text-sm text-secondary-600">
          Based on {totalVotes} votes from your area
        </div>
      </div>
      
      {/* Map Visualization */}
      <div className="bg-white p-4 rounded-lg shadow mb-6">
        <h2 className="text-lg font-medium text-secondary-800 mb-3">Geographic Distribution</h2>
        
        {loading ? (
          <div className="flex justify-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-500"></div>
          </div>
        ) : (
          <div className="relative">
            {/* This would be replaced with an actual map in production */}
            <div className="aspect-w-16 aspect-h-9 bg-gray-100 rounded-lg overflow-hidden">
              <div className="p-8 relative w-full h-full">
                {votingData.map((area) => (
                  <div
                    key={area.id}
                    className={`${getColorClass(area)} rounded-lg p-4 absolute flex flex-col justify-between text-white shadow-lg transform transition-transform hover:scale-105`}
                    style={{
                      top: `${Math.random() * 60 + 10}%`,
                      left: `${Math.random() * 60 + 10}%`,
                      width: '120px',
                      height: '110px',
                    }}
                  >
                    <div>
                      <h3 className="font-bold text-sm">{area.areaName}</h3>
                    </div>
                    <div className="text-sm">
                      <div className="flex justify-between items-center">
                        <span>👍</span>
                        <span>{area.positiveVotes}</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span>👎</span>
                        <span>{area.negativeVotes}</span>
                      </div>
                    </div>
                  </div>
                ))}
                <div className="flex items-center justify-center h-full text-lg text-secondary-400">
                  In production, this would be an interactive map with your specific division highlighted
                </div>
              </div>
            </div>
            
            {/* Legend */}
            <div className="mt-4 flex items-center justify-center space-x-4">
              <div className="flex items-center">
                <div className="w-4 h-4 bg-green-500 rounded mr-2"></div>
                <span className="text-sm">Strong Support</span>
              </div>
              <div className="flex items-center">
                <div className="w-4 h-4 bg-green-400 rounded mr-2"></div>
                <span className="text-sm">Moderate Support</span>
              </div>
              <div className="flex items-center">
                <div className="w-4 h-4 bg-yellow-400 rounded mr-2"></div>
                <span className="text-sm">Neutral</span>
              </div>
              <div className="flex items-center">
                <div className="w-4 h-4 bg-red-400 rounded mr-2"></div>
                <span className="text-sm">Moderate Opposition</span>
              </div>
              <div className="flex items-center">
                <div className="w-4 h-4 bg-red-500 rounded mr-2"></div>
                <span className="text-sm">Strong Opposition</span>
              </div>
            </div>
          </div>
        )}
      </div>
      
      {/* Area Breakdown */}
      <div className="bg-white rounded-lg shadow overflow-hidden">
        <h2 className="text-lg font-medium text-secondary-800 p-4 border-b">Area Breakdown</h2>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-secondary-500 uppercase tracking-wider">
                  Area
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-secondary-500 uppercase tracking-wider">
                  Support
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-secondary-500 uppercase tracking-wider">
                  Against
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-secondary-500 uppercase tracking-wider">
                  Total Votes
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-secondary-500 uppercase tracking-wider">
                  Sentiment
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {votingData.map((area) => (
                <tr key={area.id}>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-secondary-800">
                    {area.areaName}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-green-600 font-medium">
                    {area.positiveVotes} ({Math.round((area.positiveVotes / area.totalVotes) * 100)}%)
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-red-600 font-medium">
                    {area.negativeVotes} ({Math.round((area.negativeVotes / area.totalVotes) * 100)}%)
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-secondary-600">
                    {area.totalVotes}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="w-24 bg-gray-200 rounded-full h-2.5">
                      <div 
                        className={`${getColorClass(area)} h-2.5 rounded-full`}
                        style={{ width: `${Math.round((area.positiveVotes / area.totalVotes) * 100)}%` }}
                      ></div>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default AreaMap; 