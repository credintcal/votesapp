import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';

interface Poll {
  id: string;
  title: string;
  description: string;
  createdAt: Date;
  totalVotes: number;
  options: string[];
  active: boolean;
}

const ClientDashboard: React.FC = () => {
  const [polls, setPolls] = useState<Poll[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('active');
  
  // Get client info from localStorage
  const clientString = localStorage.getItem('user');
  const client = clientString ? JSON.parse(clientString) : { name: 'Corporator', division: 'Local Area' };
  
  useEffect(() => {
    // Fetch client's polls
    const fetchPolls = async () => {
      try {
        setLoading(true);
        
        // Mock data - in a real app, this would fetch from an API
        const mockPolls: Poll[] = [
          {
            id: '1',
            title: 'Do you support the new road development in our area?',
            description: 'Your opinion on the proposed road widening project.',
            createdAt: new Date(2023, 4, 15),
            totalVotes: 245,
            options: ['Yes', 'No', 'Need more information'],
            active: true
          },
          {
            id: '2',
            title: 'Priority for our division budget',
            description: 'What should be our main focus for development?',
            createdAt: new Date(2023, 4, 10),
            totalVotes: 192,
            options: ['Roads', 'Education', 'Healthcare', 'Parks', 'Sanitation'],
            active: true
          },
          {
            id: '3',
            title: 'Are you satisfied with the garbage collection service?',
            description: 'We want to improve our local services based on your feedback.',
            createdAt: new Date(2023, 3, 25),
            totalVotes: 310,
            options: ['Very satisfied', 'Satisfied', 'Neutral', 'Unsatisfied', 'Very unsatisfied'],
            active: false
          }
        ];
        
        setPolls(mockPolls);
        setLoading(false);
      } catch (err) {
        console.error('Error fetching polls:', err);
        setLoading(false);
      }
    };
    
    fetchPolls();
  }, []);
  
  const filteredPolls = polls.filter(poll => 
    activeTab === 'active' ? poll.active : !poll.active
  );
  
  return (
    <div className="container mx-auto px-4 py-6">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold text-secondary-800">Corporator Dashboard</h1>
          <p className="text-secondary-600">{client.name} - {client.division}</p>
        </div>
        <Link
          to="/client/create-poll"
          className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-primary-600 hover:bg-primary-700"
        >
          Create New Poll
        </Link>
      </div>
      
      {/* Analytics summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div className="bg-white p-4 rounded-lg shadow">
          <h3 className="text-lg font-medium text-secondary-800 mb-2">Total Engagement</h3>
          <p className="text-3xl font-bold text-primary-600">747</p>
          <p className="text-sm text-secondary-500">Votes across all polls</p>
        </div>
        <div className="bg-white p-4 rounded-lg shadow">
          <h3 className="text-lg font-medium text-secondary-800 mb-2">Active Polls</h3>
          <p className="text-3xl font-bold text-green-600">2</p>
          <p className="text-sm text-secondary-500">Currently running</p>
        </div>
        <div className="bg-white p-4 rounded-lg shadow">
          <h3 className="text-lg font-medium text-secondary-800 mb-2">Constituent Reach</h3>
          <p className="text-3xl font-bold text-blue-600">42%</p>
          <p className="text-sm text-secondary-500">Of registered voters participated</p>
        </div>
      </div>
      
      {/* Polls tab navigation */}
      <div className="border-b border-gray-200 mb-6">
        <nav className="flex -mb-px">
          <button
            onClick={() => setActiveTab('active')}
            className={`mr-8 py-4 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'active'
                ? 'border-primary-500 text-primary-600'
                : 'border-transparent text-secondary-500 hover:text-secondary-700 hover:border-secondary-300'
            }`}
          >
            Active Polls
          </button>
          <button
            onClick={() => setActiveTab('completed')}
            className={`mr-8 py-4 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'completed'
                ? 'border-primary-500 text-primary-600'
                : 'border-transparent text-secondary-500 hover:text-secondary-700 hover:border-secondary-300'
            }`}
          >
            Completed Polls
          </button>
        </nav>
      </div>
      
      {/* Polls list */}
      {loading ? (
        <div className="flex justify-center py-12">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-500"></div>
        </div>
      ) : (
        <div className="space-y-4">
          {filteredPolls.length === 0 ? (
            <div className="bg-gray-50 p-6 text-center rounded-lg">
              <p className="text-secondary-600">No {activeTab} polls found.</p>
              {activeTab === 'active' && (
                <Link
                  to="/client/create-poll"
                  className="mt-3 inline-flex items-center text-sm text-primary-600 hover:text-primary-800"
                >
                  Create your first poll
                </Link>
              )}
            </div>
          ) : (
            filteredPolls.map(poll => (
              <div key={poll.id} className="bg-white rounded-lg shadow p-6">
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="text-lg font-medium text-secondary-800">{poll.title}</h3>
                    <p className="text-sm text-secondary-600 mt-1">{poll.description}</p>
                  </div>
                  <div className="flex space-x-2">
                    <Link
                      to={`/client/polls/${poll.id}`}
                      className="inline-flex items-center px-3 py-1 border border-transparent text-sm rounded text-primary-700 bg-primary-100 hover:bg-primary-200"
                    >
                      {activeTab === 'active' ? 'View Live' : 'View Results'}
                    </Link>
                    {activeTab === 'active' && (
                      <button
                        className="inline-flex items-center px-3 py-1 border border-transparent text-sm rounded text-red-700 bg-red-100 hover:bg-red-200"
                      >
                        End Poll
                      </button>
                    )}
                  </div>
                </div>
                <div className="mt-4 flex items-center text-sm text-secondary-500">
                  <span className="mr-4">Created: {poll.createdAt.toLocaleDateString()}</span>
                  <span className="mr-4">Votes: {poll.totalVotes}</span>
                  <span>{poll.options.length} options</span>
                </div>
              </div>
            ))
          )}
        </div>
      )}
      
      {/* Map preview section */}
      <div className="mt-10">
        <h2 className="text-xl font-bold text-secondary-800 mb-4">Your Area Engagement Map</h2>
        <div className="bg-white p-4 rounded-lg shadow">
          <div className="aspect-w-16 aspect-h-9 bg-gray-200 rounded flex items-center justify-center">
            <div className="text-center p-6">
              <div className="text-secondary-500 mb-3">Map visualization of voter distribution and engagement</div>
              <Link
                to="/client/area-map"
                className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-primary-600 hover:bg-primary-700"
              >
                View Full Map
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ClientDashboard; 