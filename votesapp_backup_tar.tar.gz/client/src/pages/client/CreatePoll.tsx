import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

interface PollOption {
  id: string;
  text: string;
}

const CreatePoll: React.FC = () => {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [options, setOptions] = useState<PollOption[]>([
    { id: '1', text: '' },
    { id: '2', text: '' }
  ]);
  const [endDate, setEndDate] = useState('');
  const [targetAreas, setTargetAreas] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  
  const navigate = useNavigate();
  
  // Get client info from localStorage
  const clientString = localStorage.getItem('user');
  const client = clientString ? JSON.parse(clientString) : { name: 'Corporator', division: 'Local Area' };
  
  // Areas in the corporator's division
  const availableAreas = [
    { id: 'area1', name: 'North Sector' },
    { id: 'area2', name: 'Central Market' },
    { id: 'area3', name: 'East Residential' },
    { id: 'area4', name: 'West Hills' }
  ];
  
  const handleOptionChange = (id: string, value: string) => {
    setOptions(prevOptions => 
      prevOptions.map(option => 
        option.id === id ? { ...option, text: value } : option
      )
    );
  };
  
  const addOption = () => {
    const newId = (options.length + 1).toString();
    setOptions([...options, { id: newId, text: '' }]);
  };
  
  const removeOption = (id: string) => {
    if (options.length <= 2) {
      setError('A poll must have at least 2 options');
      return;
    }
    setOptions(options.filter(option => option.id !== id));
    setError('');
  };
  
  const toggleTargetArea = (areaId: string) => {
    if (targetAreas.includes(areaId)) {
      setTargetAreas(targetAreas.filter(id => id !== areaId));
    } else {
      setTargetAreas([...targetAreas, areaId]);
    }
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    
    // Basic validation
    if (!title.trim()) {
      setError('Please enter a poll title');
      setLoading(false);
      return;
    }
    
    if (!description.trim()) {
      setError('Please enter a poll description');
      setLoading(false);
      return;
    }
    
    const emptyOptions = options.filter(option => !option.text.trim());
    if (emptyOptions.length > 0) {
      setError('Please fill in all poll options');
      setLoading(false);
      return;
    }
    
    if (!endDate) {
      setError('Please select an end date for the poll');
      setLoading(false);
      return;
    }
    
    if (targetAreas.length === 0) {
      setError('Please select at least one target area');
      setLoading(false);
      return;
    }
    
    try {
      // Mock API call to create a poll
      console.log('Creating poll:', {
        title,
        description,
        options: options.map(o => o.text),
        endDate,
        targetAreas,
        createdBy: client.name,
        division: client.division
      });
      
      // Simulate a delay for the API call
      setTimeout(() => {
        setLoading(false);
        navigate('/client/dashboard', { state: { pollCreated: true } });
      }, 1000);
    } catch (err) {
      setError('Failed to create poll. Please try again.');
      console.error('Poll creation error:', err);
      setLoading(false);
    }
  };
  
  return (
    <div className="container mx-auto px-4 py-6">
      <div className="max-w-3xl mx-auto">
        <h1 className="text-2xl font-bold text-secondary-800 mb-6">Create New Poll</h1>
        
        {error && (
          <div className="mb-6 p-3 bg-red-100 text-red-700 rounded-md">
            {error}
          </div>
        )}
        
        <form onSubmit={handleSubmit}>
          <div className="bg-white rounded-lg shadow-sm overflow-hidden mb-6">
            <div className="p-6">
              <div className="mb-4">
                <label htmlFor="title" className="block text-sm font-medium text-secondary-700 mb-1">
                  Poll Title*
                </label>
                <input
                  id="title"
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="input-field"
                  placeholder="Enter a concise title for your poll"
                  maxLength={100}
                />
              </div>
              
              <div className="mb-4">
                <label htmlFor="description" className="block text-sm font-medium text-secondary-700 mb-1">
                  Description*
                </label>
                <textarea
                  id="description"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="input-field"
                  placeholder="Provide details about what you're asking"
                  rows={3}
                  maxLength={500}
                />
              </div>
              
              <div className="mb-4">
                <label className="block text-sm font-medium text-secondary-700 mb-1">
                  Poll Options*
                </label>
                <div className="space-y-3">
                  {options.map((option, index) => (
                    <div key={option.id} className="flex items-center">
                      <div className="flex-grow">
                        <input
                          type="text"
                          value={option.text}
                          onChange={(e) => handleOptionChange(option.id, e.target.value)}
                          className="input-field"
                          placeholder={`Option ${index + 1}`}
                        />
                      </div>
                      <button
                        type="button"
                        onClick={() => removeOption(option.id)}
                        className="ml-2 text-red-500 hover:text-red-700"
                      >
                        <svg className="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path>
                        </svg>
                      </button>
                    </div>
                  ))}
                </div>
                <button
                  type="button"
                  onClick={addOption}
                  className="mt-3 text-sm text-primary-600 hover:text-primary-800"
                >
                  + Add Another Option
                </button>
              </div>
              
              <div className="mb-4">
                <label htmlFor="endDate" className="block text-sm font-medium text-secondary-700 mb-1">
                  End Date*
                </label>
                <input
                  id="endDate"
                  type="date"
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                  className="input-field"
                  min={new Date().toISOString().split('T')[0]}
                />
              </div>
              
              <div className="mb-4">
                <label className="block text-sm font-medium text-secondary-700 mb-1">
                  Target Areas*
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {availableAreas.map((area) => (
                    <label key={area.id} className="flex items-center p-3 border rounded-md cursor-pointer hover:bg-gray-50">
                      <input
                        type="checkbox"
                        checked={targetAreas.includes(area.id)}
                        onChange={() => toggleTargetArea(area.id)}
                        className="h-4 w-4 text-primary-600 focus:ring-primary-500 rounded"
                      />
                      <span className="ml-2 text-sm text-secondary-700">{area.name}</span>
                    </label>
                  ))}
                </div>
              </div>
            </div>
            
            <div className="px-6 py-4 bg-gray-50 flex justify-end">
              <button
                type="button"
                onClick={() => navigate('/client/dashboard')}
                className="px-4 py-2 text-sm font-medium text-secondary-700 hover:text-secondary-900 mr-2"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={loading}
                className={`px-4 py-2 text-sm font-medium rounded-md text-white bg-primary-600 hover:bg-primary-700 ${loading ? 'opacity-70 cursor-not-allowed' : ''}`}
              >
                {loading ? 'Creating...' : 'Create Poll'}
              </button>
            </div>
          </div>
        </form>
        
        {/* Preview Section */}
        {title && (
          <div className="bg-white rounded-lg shadow-sm overflow-hidden mb-6">
            <div className="p-6">
              <h2 className="text-lg font-medium text-secondary-800 mb-4">Poll Preview</h2>
              
              <div className="border rounded-md p-4">
                <h3 className="text-xl font-semibold text-secondary-800 mb-2">{title}</h3>
                <p className="text-secondary-600 mb-4">{description}</p>
                
                <div className="space-y-2 mb-4">
                  {options.map((option, index) => (
                    <div key={option.id} className="flex items-center">
                      <input
                        type="radio"
                        name="preview-option"
                        disabled
                        className="h-4 w-4 text-primary-600"
                      />
                      <span className="ml-2 text-secondary-700">
                        {option.text || `Option ${index + 1}`}
                      </span>
                    </div>
                  ))}
                </div>
                
                <div className="text-sm text-secondary-500">
                  <div>End Date: {endDate ? new Date(endDate).toLocaleDateString() : 'Not set'}</div>
                  <div>
                    Target Areas: {targetAreas.length > 0 
                      ? availableAreas
                          .filter(area => targetAreas.includes(area.id))
                          .map(area => area.name)
                          .join(', ')
                      : 'None selected'}
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default CreatePoll; 