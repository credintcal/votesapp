import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';

// Define location state interface
interface LocationState {
  phoneNumber?: string;
  isNewUser?: boolean;
  userData?: any;
  userType?: 'voter' | 'corporator' | 'admin';
}

const VerifyOTP: React.FC = () => {
  const [otp, setOtp] = useState('');
  const [timer, setTimer] = useState(60);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  
  const location = useLocation();
  const navigate = useNavigate();
  
  // Get phone number from location state with proper typing
  const state = location.state as LocationState;
  const phoneNumber = state?.phoneNumber || '';
  const isNewUser = state?.isNewUser || false;
  const userData = state?.userData || null;
  const userType = state?.userType || 'voter';
  
  useEffect(() => {
    // Redirect if no phone number is provided
    if (!phoneNumber) {
      navigate('/auth/login');
      return;
    }
    
    // Start countdown timer
    const interval = setInterval(() => {
      setTimer((prevTimer) => {
        if (prevTimer <= 1) {
          clearInterval(interval);
          return 0;
        }
        return prevTimer - 1;
      });
    }, 1000);
    
    return () => clearInterval(interval);
  }, [phoneNumber, navigate]);
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setOtp(e.target.value);
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');
    
    try {
      // Mock successful verification for demo
      console.log('Verifying OTP:', otp, 'for phone:', phoneNumber);
      
      // For demo, we're checking if the OTP is '123456'
      if (otp === '123456') {
        // Set user data in localStorage based on user type
        if (userType === 'voter') {
          if (isNewUser && userData) {
            localStorage.setItem('user', JSON.stringify({
              ...userData,
              phone: phoneNumber,
              userType: 'voter',
              loggedIn: true
            }));
          } else {
            localStorage.setItem('user', JSON.stringify({
              name: 'Voter',
              phone: phoneNumber,
              userType: 'voter',
              loggedIn: true
            }));
          }
          navigate('/feed');
        } 
        else if (userType === 'corporator') {
          localStorage.setItem('user', JSON.stringify({
            name: 'Corporator',
            phone: phoneNumber,
            division: 'Local Area',
            userType: 'corporator',
            loggedIn: true
          }));
          navigate('/client/dashboard');
        } 
        else if (userType === 'admin') {
          localStorage.setItem('user', JSON.stringify({
            name: 'Admin',
            phone: phoneNumber,
            userType: 'admin',
            loggedIn: true
          }));
          navigate('/admin/dashboard');
        }
      } else {
        setError('Invalid OTP. Please try again.');
      }
    } catch (err) {
      setError('OTP verification failed. Please try again.');
      console.error('OTP verification error:', err);
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleResendOTP = () => {
    // Reset timer
    setTimer(60);
    // TODO: Implement actual resend OTP functionality
    console.log('Resending OTP to:', phoneNumber);
  };
  
  const getUserTypeLabel = () => {
    switch(userType) {
      case 'corporator': return 'Corporator Account';
      case 'admin': return 'Admin Account';
      default: return 'Voter Account';
    }
  };
  
  return (
    <div>
      <h2 className="text-2xl font-bold text-center text-secondary-800 mb-2">
        Verify Your Phone
      </h2>
      
      <p className="text-center text-secondary-600 mb-2">
        We've sent a 6-digit code to {phoneNumber}
      </p>
      
      <div className="mb-4 p-3 bg-blue-100 text-blue-800 rounded-md text-center">
        <p className="font-bold">DEMO MODE - {getUserTypeLabel()}</p>
        <p>Use "123456" as the OTP code</p>
        <p className="mt-1 text-sm">You will be logged in as a {userType}</p>
      </div>
      
      {error && (
        <div className="mb-4 p-3 bg-red-100 text-red-700 rounded-md text-sm">
          {error}
        </div>
      )}
      
      <form onSubmit={handleSubmit}>
        <div className="mb-6">
          <label htmlFor="otp" className="block text-sm font-medium text-secondary-700 mb-1">
            Enter OTP
          </label>
          <input
            id="otp"
            name="otp"
            type="text"
            maxLength={6}
            required
            value={otp}
            onChange={handleChange}
            className="input-field text-center tracking-widest text-lg font-bold"
            placeholder="123456"
          />
        </div>
        
        <button
          type="submit"
          disabled={isLoading || otp.length !== 6}
          className={`w-full btn-primary ${(isLoading || otp.length !== 6) ? 'opacity-70 cursor-not-allowed' : ''}`}
        >
          {isLoading ? 'Verifying...' : 'Verify OTP'}
        </button>
      </form>
      
      <div className="mt-4 text-center">
        <p className="text-sm text-secondary-600">
          Didn't receive the code?{' '}
          {timer > 0 ? (
            <span className="text-secondary-500">
              Resend in {timer} seconds
            </span>
          ) : (
            <button
              type="button"
              onClick={handleResendOTP}
              className="text-primary-600 hover:text-primary-800 font-medium"
            >
              Resend OTP
            </button>
          )}
        </p>
      </div>
    </div>
  );
};

export default VerifyOTP; 