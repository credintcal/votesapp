import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';

type UserType = 'voter' | 'corporator' | 'admin';

const Login: React.FC = () => {
  const [formData, setFormData] = useState({
    voterId: '',
    phoneNumber: ''
  });
  const [userType, setUserType] = useState<UserType>('voter');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  
  const navigate = useNavigate();
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };
  
  const handleUserTypeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setUserType(e.target.value as UserType);
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');
    
    try {
      // In demo mode, we just proceed to OTP verification
      console.log('Login attempt with:', formData, 'as', userType);
      
      // Navigate to OTP verification page
      navigate('/auth/verify-otp', { 
        state: { 
          phoneNumber: formData.phoneNumber,
          userType
        } 
      });
    } catch (err) {
      setError('Failed to login. Please check your credentials.');
      console.error('Login error:', err);
    } finally {
      setIsLoading(false);
    }
  };
  
  return (
    <div>
      <h2 className="text-2xl font-bold text-center text-secondary-800 mb-4">
        Login to VOTESAPP
      </h2>
      
      <div className="mb-4 p-3 bg-blue-100 text-blue-800 rounded-md text-center">
        <p className="font-bold">DEMO MODE</p>
        <p className="text-sm">Choose your user type and enter credentials</p>
      </div>
      
      {error && (
        <div className="mb-4 p-3 bg-red-100 text-red-700 rounded-md text-sm">
          {error}
        </div>
      )}
      
      <form onSubmit={handleSubmit}>
        <div className="mb-4">
          <label className="block text-sm font-medium text-secondary-700 mb-2">
            Select User Type
          </label>
          <div className="flex space-x-4">
            <label className="flex items-center">
              <input
                type="radio"
                name="userType"
                value="voter"
                checked={userType === 'voter'}
                onChange={handleUserTypeChange}
                className="h-4 w-4 text-primary-600 focus:ring-primary-500"
              />
              <span className="ml-2 text-sm text-secondary-700">Voter</span>
            </label>
            <label className="flex items-center">
              <input
                type="radio"
                name="userType"
                value="corporator"
                checked={userType === 'corporator'}
                onChange={handleUserTypeChange}
                className="h-4 w-4 text-primary-600 focus:ring-primary-500"
              />
              <span className="ml-2 text-sm text-secondary-700">Corporator</span>
            </label>
            <label className="flex items-center">
              <input
                type="radio"
                name="userType"
                value="admin"
                checked={userType === 'admin'}
                onChange={handleUserTypeChange}
                className="h-4 w-4 text-primary-600 focus:ring-primary-500"
              />
              <span className="ml-2 text-sm text-secondary-700">Admin</span>
            </label>
          </div>
        </div>
        
        {userType === 'voter' && (
          <div className="mb-4">
            <label htmlFor="voterId" className="block text-sm font-medium text-secondary-700 mb-1">
              Voter ID
            </label>
            <input
              id="voterId"
              name="voterId"
              type="text"
              required
              value={formData.voterId}
              onChange={handleChange}
              className="input-field"
              placeholder="Enter your Voter ID"
            />
          </div>
        )}
        
        {userType === 'corporator' && (
          <div className="mb-4">
            <label htmlFor="voterId" className="block text-sm font-medium text-secondary-700 mb-1">
              Corporator ID
            </label>
            <input
              id="voterId"
              name="voterId"
              type="text"
              required
              value={formData.voterId}
              onChange={handleChange}
              className="input-field"
              placeholder="Enter your Corporator ID"
            />
          </div>
        )}
        
        {userType === 'admin' && (
          <div className="mb-4">
            <label htmlFor="voterId" className="block text-sm font-medium text-secondary-700 mb-1">
              Admin ID
            </label>
            <input
              id="voterId"
              name="voterId"
              type="text"
              required
              value={formData.voterId}
              onChange={handleChange}
              className="input-field"
              placeholder="Enter your Admin ID"
            />
          </div>
        )}
        
        <div className="mb-6">
          <label htmlFor="phoneNumber" className="block text-sm font-medium text-secondary-700 mb-1">
            Phone Number
          </label>
          <input
            id="phoneNumber"
            name="phoneNumber"
            type="tel"
            required
            value={formData.phoneNumber}
            onChange={handleChange}
            className="input-field"
            placeholder="Enter your phone number"
          />
        </div>
        
        <button
          type="submit"
          disabled={isLoading}
          className={`w-full btn-primary ${isLoading ? 'opacity-70 cursor-not-allowed' : ''}`}
        >
          {isLoading ? 'Processing...' : 'Send OTP'}
        </button>
      </form>
      
      <div className="mt-6 text-center text-sm">
        <p className="text-secondary-600">
          {userType === 'voter' && (
            <>
              Don't have an account?{' '}
              <Link to="/auth/register" className="text-primary-600 hover:text-primary-800 font-medium">
                Register here
              </Link>
            </>
          )}
          {userType === 'corporator' && (
            <span className="text-secondary-500">
              Corporators need approval from the admin to create an account.
            </span>
          )}
          {userType === 'admin' && (
            <span className="text-secondary-500">
              Admin account is only for the head of the political party.
            </span>
          )}
        </p>
      </div>
    </div>
  );
};

export default Login; 