import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';

interface Coordinates {
  latitude: number | null;
  longitude: number | null;
}

interface LocationDetails {
  city: string;
  state: string;
  country: string;
}

const Register: React.FC = () => {
  const [formData, setFormData] = useState({
    fullName: '',
    voterId: '',
    phoneNumber: '',
    gender: '',
    birthdate: '',
    address: '',
  });
  
  const [coordinates, setCoordinates] = useState<Coordinates>({
    latitude: null,
    longitude: null
  });
  
  const [locationDetails, setLocationDetails] = useState<LocationDetails>({
    city: '',
    state: '',
    country: ''
  });
  
  const [isLoading, setIsLoading] = useState(false);
  const [isGettingLocation, setIsGettingLocation] = useState(false);
  const [locationError, setLocationError] = useState('');
  const [error, setError] = useState('');
  
  const navigate = useNavigate();
  
  // Get current location when component mounts
  useEffect(() => {
    handleGetLocation();
  }, []);
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };
  
  const handleGetLocation = () => {
    setIsGettingLocation(true);
    setLocationError('');
    
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        async (position) => {
          const { latitude, longitude } = position.coords;
          setCoordinates({ latitude, longitude });
          
          // In a real app, we would use a reverse geocoding service here
          // For now, just mock the location details
          setLocationDetails({
            city: 'Demo City',
            state: 'Demo State',
            country: 'Demo Country'
          });
          
          setIsGettingLocation(false);
        },
        (error) => {
          console.error('Error getting location:', error);
          setLocationError('Failed to get your location. Please try again or enter manually.');
          setIsGettingLocation(false);
        },
        { timeout: 10000 }
      );
    } else {
      setLocationError('Geolocation is not supported by your browser.');
      setIsGettingLocation(false);
    }
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');
    
    // Simple validation
    if (!formData.fullName || !formData.voterId || !formData.phoneNumber || 
        !formData.gender || !formData.birthdate || !formData.address) {
      setError('All fields are required.');
      setIsLoading(false);
      return;
    }
    
    // Calculate age from birthdate
    const birthDate = new Date(formData.birthdate);
    const today = new Date();
    let age = today.getFullYear() - birthDate.getFullYear();
    const m = today.getMonth() - birthDate.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    
    // Validate age
    if (age < 18) {
      setError('You must be at least 18 years old to register.');
      setIsLoading(false);
      return;
    }
    
    try {
      // TODO: Implement actual registration with Firebase
      // Mock successful registration for now
      console.log('Registration attempt with:', formData);
      console.log('User location:', coordinates, locationDetails);
      
      // Prepare user data to pass to OTP verification
      const userData = {
        ...formData,
        age,
        location: {
          ...coordinates,
          ...locationDetails
        },
        registeredAt: new Date().toISOString()
      };
      
      // Navigate to OTP verification page
      navigate('/auth/verify-otp', { 
        state: { 
          phoneNumber: formData.phoneNumber,
          isNewUser: true,
          userData
        } 
      });
    } catch (err) {
      setError('Registration failed. Please try again.');
      console.error('Registration error:', err);
    } finally {
      setIsLoading(false);
    }
  };
  
  return (
    <div>
      <h2 className="text-2xl font-bold text-center text-secondary-800 mb-4">
        Register for VOTESAPP
      </h2>
      
      <div className="mb-4 p-3 bg-blue-100 text-blue-800 rounded-md text-center">
        <p className="font-bold">DEMO MODE</p>
        <p className="text-sm">Complete all fields to register</p>
        <p className="text-sm mt-1">You'll receive OTP code "123456" on the next screen</p>
      </div>
      
      {error && (
        <div className="mb-4 p-3 bg-red-100 text-red-700 rounded-md text-sm">
          {error}
        </div>
      )}
      
      <form onSubmit={handleSubmit}>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
          <div>
            <label htmlFor="fullName" className="block text-sm font-medium text-secondary-700 mb-1">
              Full Name*
            </label>
            <input
              id="fullName"
              name="fullName"
              type="text"
              required
              value={formData.fullName}
              onChange={handleChange}
              className="input-field"
              placeholder="Enter your full name"
            />
          </div>
          
          <div>
            <label htmlFor="voterId" className="block text-sm font-medium text-secondary-700 mb-1">
              Voter ID*
            </label>
            <input
              id="voterId"
              name="voterId"
              type="text"
              required
              value={formData.voterId}
              onChange={handleChange}
              className="input-field"
              placeholder="Enter your Voter ID"
            />
          </div>
          
          <div>
            <label htmlFor="phoneNumber" className="block text-sm font-medium text-secondary-700 mb-1">
              Phone Number*
            </label>
            <input
              id="phoneNumber"
              name="phoneNumber"
              type="tel"
              required
              value={formData.phoneNumber}
              onChange={handleChange}
              className="input-field"
              placeholder="Enter your phone number"
            />
          </div>
          
          <div>
            <label htmlFor="gender" className="block text-sm font-medium text-secondary-700 mb-1">
              Gender*
            </label>
            <select
              id="gender"
              name="gender"
              required
              value={formData.gender}
              onChange={handleChange}
              className="input-field"
            >
              <option value="">Select gender</option>
              <option value="male">Male</option>
              <option value="female">Female</option>
              <option value="other">Other</option>
              <option value="prefer_not_to_say">Prefer not to say</option>
            </select>
          </div>
          
          <div>
            <label htmlFor="birthdate" className="block text-sm font-medium text-secondary-700 mb-1">
              Date of Birth*
            </label>
            <input
              id="birthdate"
              name="birthdate"
              type="date"
              required
              value={formData.birthdate}
              onChange={handleChange}
              className="input-field"
              max={new Date().toISOString().split('T')[0]}
            />
            <p className="text-xs text-secondary-500 mt-1">You must be at least 18 years old</p>
          </div>
        </div>
        
        <div className="mb-6">
          <label htmlFor="address" className="block text-sm font-medium text-secondary-700 mb-1">
            Address*
          </label>
          <textarea
            id="address"
            name="address"
            required
            value={formData.address}
            onChange={handleChange}
            className="input-field"
            rows={3}
            placeholder="Enter your address"
          />
        </div>
        
        <div className="mb-6 p-4 bg-gray-50 rounded-md">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-sm font-medium text-secondary-700">Your Location</h3>
            <button
              type="button"
              onClick={handleGetLocation}
              disabled={isGettingLocation}
              className="text-sm text-primary-600 hover:text-primary-800"
            >
              {isGettingLocation ? 'Getting location...' : 'Get My Location'}
            </button>
          </div>
          
          {locationError && (
            <p className="text-xs text-red-600 mb-2">{locationError}</p>
          )}
          
          {coordinates.latitude && coordinates.longitude ? (
            <div className="text-sm text-secondary-600">
              <p className="mb-1">
                {locationDetails.city}, {locationDetails.state}, {locationDetails.country}
              </p>
              <p className="text-xs text-secondary-500">
                Coordinates: {coordinates.latitude.toFixed(6)}, {coordinates.longitude.toFixed(6)}
              </p>
            </div>
          ) : (
            <p className="text-sm text-secondary-500">
              {isGettingLocation ? 'Detecting your location...' : 'Click the button to detect your location'}
            </p>
          )}
        </div>
        
        <button
          type="submit"
          disabled={isLoading}
          className={`w-full btn-primary ${isLoading ? 'opacity-70 cursor-not-allowed' : ''}`}
        >
          {isLoading ? 'Processing...' : 'Register'}
        </button>
      </form>
      
      <div className="mt-6 text-center text-sm">
        <p className="text-secondary-600">
          Already have an account?{' '}
          <Link to="/auth/login" className="text-primary-600 hover:text-primary-800 font-medium">
            Login here
          </Link>
        </p>
      </div>
    </div>
  );
};

export default Register; 