import React from 'react';
import { Outlet, Link } from 'react-router-dom';

const AuthLayout: React.FC = () => {
  return (
    <div className="flex min-h-screen bg-gradient-to-br from-primary-600 to-primary-800">
      <div className="w-full max-w-md m-auto bg-white rounded-lg shadow-xl overflow-hidden">
        <div className="p-6">
          {/* Logo */}
          <div className="flex justify-center mb-8">
            <Link to="/" className="flex items-center space-x-2">
              <svg className="h-10 w-10 text-primary-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M7 11l5-5m0 0l5 5m-5-5v12"></path>
              </svg>
              <span className="text-2xl font-bold text-primary-600">VOTESAPP</span>
            </Link>
          </div>
          
          {/* Auth Form Container */}
          <Outlet />
          
          {/* Footer */}
          <div className="mt-8 text-center text-sm text-secondary-500">
            <p>&copy; {new Date().getFullYear()} VOTESAPP. All rights reserved.</p>
            <p className="mt-2">
              <Link to="/" className="text-primary-600 hover:text-primary-800">
                Return to Home
              </Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AuthLayout; 