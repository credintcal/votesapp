import React, { useState, useEffect } from 'react';
import { Outlet, Link, useNavigate, useLocation } from 'react-router-dom';

const MainLayout: React.FC = () => {
  const [user, setUser] = useState<any>(null);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();
  
  // Check if the user is logged in
  useEffect(() => {
    const userString = localStorage.getItem('user');
    if (userString) {
      try {
        const userData = JSON.parse(userString);
        setUser(userData);
      } catch (e) {
        console.error('Error parsing user data:', e);
      }
    }
  }, [location.pathname]); // Re-check on path change
  
  const handleLogout = () => {
    localStorage.removeItem('user');
    setUser(null);
    navigate('/');
  };
  
  return (
    <div className="flex flex-col min-h-screen">
      {/* Header / Navbar */}
      <header className="bg-primary-600 text-white shadow-md">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <svg className="h-8 w-8" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M7 11l5-5m0 0l5 5m-5-5v12"></path>
              </svg>
              <Link to={user ? '/feed' : '/'} className="text-xl font-bold">VOTESAPP</Link>
            </div>
            
            {/* Main Navigation */}
            <nav className="hidden md:flex space-x-6">
              {user ? (
                // Authenticated navigation
                <>
                  <Link to="/feed" className="hover:text-primary-200 transition duration-150">Feed</Link>
                  {user.isAdmin && (
                    <Link to="/admin/dashboard" className="hover:text-primary-200 transition duration-150">Admin</Link>
                  )}
                </>
              ) : (
                // Public navigation
                <>
                  <Link to="/" className="hover:text-primary-200 transition duration-150">Home</Link>
                  <Link to="/about" className="hover:text-primary-200 transition duration-150">About</Link>
                </>
              )}
            </nav>
            
            {/* Auth Links */}
            <div className="hidden md:flex items-center space-x-4">
              {user ? (
                // User is logged in
                <div className="flex items-center space-x-4">
                  <span className="text-sm">Hello, {user.name || 'User'}</span>
                  <button 
                    onClick={handleLogout}
                    className="bg-white text-primary-600 px-3 py-1 rounded-md hover:bg-primary-100 transition duration-150"
                  >
                    Logout
                  </button>
                </div>
              ) : (
                // User is not logged in
                <>
                  <Link to="/auth/login" className="hover:text-primary-200 transition duration-150">Login</Link>
                  <Link to="/auth/register" className="bg-white text-primary-600 px-4 py-2 rounded-md hover:bg-primary-100 transition duration-150">Register</Link>
                </>
              )}
            </div>
            
            {/* Mobile Menu Button */}
            <div className="md:hidden">
              <button 
                className="text-white"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              >
                <svg className="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16M4 18h16"></path>
                </svg>
              </button>
            </div>
          </div>
          
          {/* Mobile Menu */}
          {mobileMenuOpen && (
            <div className="md:hidden pt-4 pb-2">
              <div className="flex flex-col space-y-3">
                {user ? (
                  // Authenticated mobile navigation
                  <>
                    <Link to="/feed" className="hover:text-primary-200 transition duration-150">Feed</Link>
                    {user.isAdmin && (
                      <Link to="/admin/dashboard" className="hover:text-primary-200 transition duration-150">Admin</Link>
                    )}
                    <button 
                      onClick={handleLogout}
                      className="text-left hover:text-primary-200 transition duration-150"
                    >
                      Logout
                    </button>
                  </>
                ) : (
                  // Public mobile navigation
                  <>
                    <Link to="/" className="hover:text-primary-200 transition duration-150">Home</Link>
                    <Link to="/about" className="hover:text-primary-200 transition duration-150">About</Link>
                    <Link to="/auth/login" className="hover:text-primary-200 transition duration-150">Login</Link>
                    <Link to="/auth/register" className="hover:text-primary-200 transition duration-150">Register</Link>
                  </>
                )}
              </div>
            </div>
          )}
        </div>
      </header>
      
      {/* Main Content */}
      <main className="flex-grow container mx-auto px-4 py-6">
        <Outlet />
      </main>
      
      {/* Footer */}
      <footer className="bg-secondary-800 text-white py-6">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <h3 className="text-lg font-semibold mb-4">VOTESAPP</h3>
              <p className="text-secondary-300">
                A free, real-time public opinion platform for political parties.
              </p>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Links</h3>
              <ul className="space-y-2">
                {user ? (
                  <>
                    <li><Link to="/feed" className="text-secondary-300 hover:text-white transition">Feed</Link></li>
                  </>
                ) : (
                  <>
                    <li><Link to="/" className="text-secondary-300 hover:text-white transition">Home</Link></li>
                    <li><Link to="/about" className="text-secondary-300 hover:text-white transition">About</Link></li>
                    <li><Link to="/auth/login" className="text-secondary-300 hover:text-white transition">Login</Link></li>
                  </>
                )}
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Contact</h3>
              <p className="text-secondary-300">
                Email: info@votesapp.com<br />
                Phone: +1 (123) 456-7890
              </p>
            </div>
          </div>
          <div className="mt-8 pt-6 border-t border-secondary-700 text-center text-sm text-secondary-400">
            <p>&copy; {new Date().getFullYear()} VOTESAPP. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default MainLayout; 